using System.Net;
using System.Net.Http.Json;
using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using EnterpriseEmployeeManagement.IntegrationTests.Infrastructure;

namespace EnterpriseEmployeeManagement.IntegrationTests;

public sealed class AuthenticationEndpointTests(EmployeeApiFactory factory) : IClassFixture<EmployeeApiFactory>
{
    [Fact]
    public async Task Login_WithUnknownUser_ReturnsUnauthorizedProblemDetails()
    {
        using HttpClient client = factory.CreateHttpsClient();

        using HttpResponseMessage response = await client.PostAsJsonAsync(
            "/api/v1/auth/login",
            new LoginRequest("unknown", "ValidPassword!123"));

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType?.MediaType);
    }
}
