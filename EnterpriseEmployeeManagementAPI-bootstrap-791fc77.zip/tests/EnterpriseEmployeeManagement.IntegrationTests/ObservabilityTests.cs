using EnterpriseEmployeeManagement.IntegrationTests.Infrastructure;

namespace EnterpriseEmployeeManagement.IntegrationTests;

public sealed class ObservabilityTests(EmployeeApiFactory factory) : IClassFixture<EmployeeApiFactory>
{
    [Fact]
    public async Task Request_ReturnsCorrelationHeader()
    {
        using HttpClient client = factory.CreateHttpsClient();

        using HttpResponseMessage response = await client.GetAsync("/health/live");

        Assert.True(response.Headers.Contains("X-Correlation-ID"));
    }
}
