using System.Net;
using EnterpriseEmployeeManagement.IntegrationTests.Infrastructure;

namespace EnterpriseEmployeeManagement.IntegrationTests;

public sealed class AuthorizationTests(EmployeeApiFactory factory) : IClassFixture<EmployeeApiFactory>
{
    [Theory]
    [InlineData("/api/v1/employees")]
    [InlineData("/api/v1/payroll")]
    [InlineData("/api/v1/roles")]
    public async Task ProtectedEndpoint_RejectsAnonymousRequest(string path)
    {
        using HttpClient client = factory.CreateHttpsClient();

        using HttpResponseMessage response = await client.GetAsync(path);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }
}
