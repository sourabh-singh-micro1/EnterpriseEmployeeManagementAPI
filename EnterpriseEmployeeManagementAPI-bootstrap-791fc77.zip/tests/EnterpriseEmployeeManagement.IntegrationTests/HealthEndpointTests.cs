using System.Net;
using EnterpriseEmployeeManagement.IntegrationTests.Infrastructure;

namespace EnterpriseEmployeeManagement.IntegrationTests;

public sealed class HealthEndpointTests(EmployeeApiFactory factory) : IClassFixture<EmployeeApiFactory>
{
    [Theory]
    [InlineData("/health/live")]
    [InlineData("/health/ready")]
    public async Task HealthEndpoint_ReturnsSuccess(string path)
    {
        using HttpClient client = factory.CreateHttpsClient();

        using HttpResponseMessage response = await client.GetAsync(path);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
