using System.Net;
using EnterpriseEmployeeManagement.IntegrationTests.Infrastructure;

namespace EnterpriseEmployeeManagement.IntegrationTests;

public sealed class SwaggerTests(EmployeeApiFactory factory) : IClassFixture<EmployeeApiFactory>
{
    [Fact]
    public async Task SwaggerDocument_IsAvailableInDevelopment()
    {
        using HttpClient client = factory.CreateHttpsClient();

        using HttpResponseMessage response = await client.GetAsync("/swagger/v1/swagger.json");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }
}
