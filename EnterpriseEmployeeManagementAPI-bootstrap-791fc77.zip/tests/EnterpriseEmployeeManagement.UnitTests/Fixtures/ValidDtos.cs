using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.UnitTests.Fixtures;

internal static class ValidDtos
{
    public static EmployeeDto Employee() => new()
    {
        EmployeeNumber = "EMP-1001",
        FirstName = "Ada",
        LastName = "Lovelace",
        Email = "ada@example.invalid",
        DepartmentId = Guid.NewGuid(),
        HireDate = new DateOnly(2024, 1, 1),
        BaseSalary = 100_000,
        Currency = "USD",
    };

    public static DepartmentDto Department() => new()
    {
        Name = "Engineering",
        Code = "ENG",
        CostCenter = "CC-2000",
        AnnualBudget = 1_000_000,
    };

    public static ProjectDto Project() => new()
    {
        Name = "Atlas",
        Code = "ATLAS",
        DepartmentId = Guid.NewGuid(),
        StartDate = new DateOnly(2026, 1, 1),
        EndDate = new DateOnly(2026, 12, 31),
        Budget = 200_000,
    };

    public static AttendanceDto Attendance() => new()
    {
        EmployeeId = Guid.NewGuid(),
        WorkDate = new DateOnly(2026, 1, 2),
        CheckInUtc = new DateTimeOffset(2026, 1, 2, 9, 0, 0, TimeSpan.Zero),
        CheckOutUtc = new DateTimeOffset(2026, 1, 2, 17, 0, 0, TimeSpan.Zero),
        WorkMinutes = 480,
        Status = AttendanceStatus.Present,
    };

    public static LeaveRequestDto Leave() => new()
    {
        EmployeeId = Guid.NewGuid(),
        LeaveType = LeaveType.Annual,
        StartDate = new DateOnly(2026, 2, 1),
        EndDate = new DateOnly(2026, 2, 3),
        Reason = "Annual leave",
    };

    public static RoleDto Role() => new()
    {
        Name = "Auditor",
        Description = "Read-only audit access",
        Permissions = "audit.read",
    };

    public static UserDto User() => new()
    {
        Username = "ada.lovelace",
        Email = "ada@example.invalid",
        Password = "ValidPassword!123",
        EmployeeId = Guid.NewGuid(),
        RoleId = Guid.NewGuid(),
    };

    public static PayrollDto Payroll() => new()
    {
        EmployeeId = Guid.NewGuid(),
        PeriodStart = new DateOnly(2026, 1, 1),
        PeriodEnd = new DateOnly(2026, 1, 31),
        GrossPay = 10_000,
        Deductions = 2_000,
        NetPay = 8_000,
        Currency = "USD",
    };

    public static PerformanceReviewDto Review() => new()
    {
        EmployeeId = Guid.NewGuid(),
        ReviewerId = Guid.NewGuid(),
        ReviewPeriodStart = new DateOnly(2025, 1, 1),
        ReviewPeriodEnd = new DateOnly(2025, 12, 31),
        Score = 4,
        Strengths = "Delivery",
        ImprovementAreas = "Delegation",
        Goals = "Mentor two engineers",
    };
}
