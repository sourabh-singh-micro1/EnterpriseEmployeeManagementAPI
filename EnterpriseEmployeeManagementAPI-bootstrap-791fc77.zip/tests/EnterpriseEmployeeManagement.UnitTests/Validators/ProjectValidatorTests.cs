using EnterpriseEmployeeManagement.Application.Projects.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class ProjectValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidProject() => Assert.True(new ProjectDtoValidator().Validate(ValidDtos.Project()).IsValid);

    [Fact]
    public void Validate_RejectsReversedDates()
    {
        var dto = ValidDtos.Project();
        dto.EndDate = dto.StartDate.AddDays(-1);
        Assert.False(new ProjectDtoValidator().Validate(dto).IsValid);
    }
}
