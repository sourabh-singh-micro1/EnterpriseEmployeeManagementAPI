using EnterpriseEmployeeManagement.Application.Attendance.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class AttendanceValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidAttendance() => Assert.True(new AttendanceDtoValidator().Validate(ValidDtos.Attendance()).IsValid);

    [Fact]
    public void Validate_RejectsCheckoutBeforeCheckin()
    {
        var dto = ValidDtos.Attendance();
        dto.CheckOutUtc = dto.CheckInUtc!.Value.AddMinutes(-1);
        Assert.False(new AttendanceDtoValidator().Validate(dto).IsValid);
    }
}
