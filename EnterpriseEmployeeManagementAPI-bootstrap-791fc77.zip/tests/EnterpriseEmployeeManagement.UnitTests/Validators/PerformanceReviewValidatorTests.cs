using EnterpriseEmployeeManagement.Application.PerformanceReviews.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class PerformanceReviewValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidReview() => Assert.True(new PerformanceReviewDtoValidator().Validate(ValidDtos.Review()).IsValid);

    [Fact]
    public void Validate_RejectsSelfReview()
    {
        var dto = ValidDtos.Review();
        dto.ReviewerId = dto.EmployeeId;
        Assert.False(new PerformanceReviewDtoValidator().Validate(dto).IsValid);
    }
}
