using EnterpriseEmployeeManagement.Application.UserManagement.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class UserValidatorTests
{
    [Fact]
    public void Validate_AcceptsStrongPassword() => Assert.True(new UserDtoValidator().Validate(ValidDtos.User()).IsValid);

    [Fact]
    public void Validate_RejectsWeakPassword()
    {
        var dto = ValidDtos.User();
        dto.Password = "weak";
        Assert.False(new UserDtoValidator().Validate(dto).IsValid);
    }
}
