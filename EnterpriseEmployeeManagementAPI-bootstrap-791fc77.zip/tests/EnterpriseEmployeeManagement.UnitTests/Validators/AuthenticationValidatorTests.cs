using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using EnterpriseEmployeeManagement.Application.Authentication.Validators;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class AuthenticationValidatorTests
{
    [Fact]
    public void Login_RejectsBlankCredentials()
        => Assert.False(new LoginRequestValidator().Validate(new LoginRequest(string.Empty, string.Empty)).IsValid);

    [Fact]
    public void Registration_AcceptsStrongCredentials()
    {
        RegisterUserRequest request = new("employee.user", "employee@example.invalid", "ValidPassword!123", Guid.NewGuid(), Guid.NewGuid());
        Assert.True(new RegisterUserRequestValidator().Validate(request).IsValid);
    }

    [Fact]
    public void Registration_RejectsWeakCredentials()
    {
        RegisterUserRequest request = new("x", "invalid", "weak", Guid.Empty, Guid.Empty);
        Assert.False(new RegisterUserRequestValidator().Validate(request).IsValid);
    }
}
