using EnterpriseEmployeeManagement.Application.Roles.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class RoleValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidRole() => Assert.True(new RoleDtoValidator().Validate(ValidDtos.Role()).IsValid);

    [Fact]
    public void Validate_RejectsMissingPermissions()
    {
        var dto = ValidDtos.Role();
        dto.Permissions = string.Empty;
        Assert.False(new RoleDtoValidator().Validate(dto).IsValid);
    }
}
