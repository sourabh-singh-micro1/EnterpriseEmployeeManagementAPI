using EnterpriseEmployeeManagement.Application.LeaveManagement.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class LeaveValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidLeave() => Assert.True(new LeaveRequestDtoValidator().Validate(ValidDtos.Leave()).IsValid);

    [Fact]
    public void Validate_RejectsMissingReason()
    {
        var dto = ValidDtos.Leave();
        dto.Reason = string.Empty;
        Assert.False(new LeaveRequestDtoValidator().Validate(dto).IsValid);
    }
}
