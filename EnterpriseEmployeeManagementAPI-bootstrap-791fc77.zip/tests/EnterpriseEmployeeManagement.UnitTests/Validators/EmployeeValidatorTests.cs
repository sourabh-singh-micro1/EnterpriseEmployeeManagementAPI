using EnterpriseEmployeeManagement.Application.Employees.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class EmployeeValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidEmployee() => Assert.True(new EmployeeDtoValidator().Validate(ValidDtos.Employee()).IsValid);

    [Fact]
    public void Validate_RejectsInvalidIdentity()
    {
        var dto = ValidDtos.Employee();
        dto.Email = "invalid";
        dto.EmployeeNumber = "bad number";

        Assert.False(new EmployeeDtoValidator().Validate(dto).IsValid);
    }
}
