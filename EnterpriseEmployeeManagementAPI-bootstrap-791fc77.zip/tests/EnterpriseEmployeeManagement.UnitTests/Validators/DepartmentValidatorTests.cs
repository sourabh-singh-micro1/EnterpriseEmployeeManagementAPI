using EnterpriseEmployeeManagement.Application.Departments.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class DepartmentValidatorTests
{
    [Fact]
    public void Validate_AcceptsValidDepartment() => Assert.True(new DepartmentDtoValidator().Validate(ValidDtos.Department()).IsValid);

    [Fact]
    public void Validate_RejectsNegativeBudget()
    {
        var dto = ValidDtos.Department();
        dto.AnnualBudget = -1;
        Assert.False(new DepartmentDtoValidator().Validate(dto).IsValid);
    }
}
