using EnterpriseEmployeeManagement.Application.Payroll.Validators;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;

namespace EnterpriseEmployeeManagement.UnitTests.Validators;

public sealed class PayrollValidatorTests
{
    [Fact]
    public void Validate_AcceptsBalancedPayroll() => Assert.True(new PayrollDtoValidator().Validate(ValidDtos.Payroll()).IsValid);

    [Fact]
    public void Validate_RejectsIncorrectNetPay()
    {
        var dto = ValidDtos.Payroll();
        dto.NetPay++;
        Assert.False(new PayrollDtoValidator().Validate(dto).IsValid);
    }
}
