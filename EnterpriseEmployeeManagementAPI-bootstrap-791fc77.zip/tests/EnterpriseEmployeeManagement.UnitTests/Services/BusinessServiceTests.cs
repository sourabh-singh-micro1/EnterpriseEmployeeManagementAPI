using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Employees.Services;
using EnterpriseEmployeeManagement.Application.Employees.Validators;
using EnterpriseEmployeeManagement.Application.Projects.Services;
using EnterpriseEmployeeManagement.Application.Projects.Validators;
using EnterpriseEmployeeManagement.Application.Roles.Services;
using EnterpriseEmployeeManagement.Application.Roles.Validators;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.UnitTests.Fixtures;
using Moq;

namespace EnterpriseEmployeeManagement.UnitTests.Services;

public sealed class BusinessServiceTests
{
    [Fact]
    public async Task Employee_CreateRejectsFutureHireDate()
    {
        var unitOfWork = new Mock<IUnitOfWork>();
        var employees = new Mock<IRepository<Employee>>();
        var departments = new Mock<IRepository<Department>>();
        var clock = new Mock<IClock>();
        unitOfWork.Setup(work => work.Repository<Employee>()).Returns(employees.Object);
        unitOfWork.Setup(work => work.Repository<Department>()).Returns(departments.Object);
        employees.Setup(repository => repository.AnyAsync(It.IsAny<IQueryable<Employee>>(), It.IsAny<CancellationToken>())).ReturnsAsync(false);
        departments.Setup(repository => repository.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Department { IsActive = true });
        clock.SetupGet(value => value.Today).Returns(new DateOnly(2026, 1, 1));
        var service = new EmployeeService(unitOfWork.Object, Mock.Of<IMapper>(), new EmployeeDtoValidator(), clock.Object);
        var dto = ValidDtos.Employee();
        dto.HireDate = new DateOnly(2026, 1, 2);

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.CreateAsync(dto, CancellationToken.None));
    }

    [Fact]
    public async Task Project_CreateRejectsBudgetAboveDepartmentBudget()
    {
        var unitOfWork = new Mock<IUnitOfWork>();
        var projects = new Mock<IRepository<Project>>();
        var departments = new Mock<IRepository<Department>>();
        unitOfWork.Setup(work => work.Repository<Project>()).Returns(projects.Object);
        unitOfWork.Setup(work => work.Repository<Department>()).Returns(departments.Object);
        projects.Setup(repository => repository.AnyAsync(It.IsAny<IQueryable<Project>>(), It.IsAny<CancellationToken>())).ReturnsAsync(false);
        departments.Setup(repository => repository.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Department { IsActive = true, AnnualBudget = 10 });
        var service = new ProjectService(unitOfWork.Object, Mock.Of<IMapper>(), new ProjectDtoValidator());
        var dto = ValidDtos.Project();
        dto.Budget = 11;

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.CreateAsync(dto, CancellationToken.None));
    }

    [Fact]
    public async Task Role_DeleteProtectsSystemRole()
    {
        var unitOfWork = new Mock<IUnitOfWork>();
        var roles = new Mock<IRepository<Role>>();
        unitOfWork.Setup(work => work.Repository<Role>()).Returns(roles.Object);
        roles.Setup(repository => repository.GetByIdAsync(It.IsAny<Guid>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Role { IsSystemRole = true, Name = "Administrator" });
        var service = new RoleService(unitOfWork.Object, Mock.Of<IMapper>(), new RoleDtoValidator());

        await Assert.ThrowsAsync<BusinessRuleException>(() => service.DeleteAsync(Guid.NewGuid(), CancellationToken.None));
    }
}
