using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Services;
using EnterpriseEmployeeManagement.Domain.ValueObjects;

namespace EnterpriseEmployeeManagement.UnitTests.Domain;

public sealed class DomainValueAndServiceTests
{
    [Fact]
    public void Money_RoundsAndNormalizesCurrency()
    {
        Money value = new(12.345m, "usd");

        Assert.Equal(12.34m, value.Amount);
        Assert.Equal("USD", value.Currency);
        Assert.Equal("USD", new Money(1, string.Empty).Currency);
    }

    [Fact]
    public void Money_RejectsNegativeAmount()
        => Assert.Throws<DomainException>(() => new Money(-1, "USD"));

    [Fact]
    public void DateRange_CountsBoundariesAndDetectsOverlap()
    {
        DateRange first = new(new DateOnly(2026, 1, 1), new DateOnly(2026, 1, 3));
        DateRange second = new(new DateOnly(2026, 1, 3), new DateOnly(2026, 1, 5));

        Assert.Equal(3, first.InclusiveDays);
        Assert.True(first.Overlaps(second));
    }

    [Fact]
    public void DateRange_RejectsReversedRange()
        => Assert.Throws<DomainException>(() => new DateRange(new DateOnly(2026, 2, 1), new DateOnly(2026, 1, 1)));

    [Fact]
    public void PayrollCalculator_ComputesAndValidates()
    {
        Assert.Equal(4_500, PayrollCalculator.CalculateNetPay(5_000, 500, 1_000, "USD").Amount);
        Assert.Throws<DomainException>(() => PayrollCalculator.CalculateNetPay(100, 0, 101, "USD"));
    }

    [Fact]
    public void WorkingDayCalculator_ExcludesWeekend()
        => Assert.Equal(
            3,
            WorkingDayCalculator.CountWorkingDays(new DateOnly(2026, 1, 1), new DateOnly(2026, 1, 5)));
}
