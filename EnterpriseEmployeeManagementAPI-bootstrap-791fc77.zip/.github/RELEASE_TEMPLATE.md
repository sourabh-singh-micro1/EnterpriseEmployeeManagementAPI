# vX.Y.Z

## Highlights

## Changes

## Security and dependencies

## Database migration notes

## Deployment verification

## Rollback plan
