## Summary

## Related issue

Closes #

## Type

- [ ] Feature
- [ ] Fix
- [ ] Refactor
- [ ] Database migration
- [ ] Documentation

## Validation

- [ ] Format verification
- [ ] Build
- [ ] Unit tests
- [ ] Integration tests
- [ ] Coverage at least 80%
- [ ] Dependency audit
- [ ] Migration and rollback reviewed
- [ ] No secrets or personal employee data

## Risk and rollback

## Reviewer notes
