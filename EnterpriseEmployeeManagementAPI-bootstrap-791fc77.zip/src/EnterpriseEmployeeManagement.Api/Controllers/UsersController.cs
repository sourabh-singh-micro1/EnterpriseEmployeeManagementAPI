using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,HR")]
[Route("api/v1/users")]
public sealed class UsersController(IEnterpriseCrudService<UserDto> service)
    : EnterpriseCrudController<UserDto>(service);
