using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,HR")]
[Route("api/v1/payroll")]
public sealed class PayrollController(IEnterpriseCrudService<PayrollDto> service)
    : EnterpriseCrudController<PayrollDto>(service);
