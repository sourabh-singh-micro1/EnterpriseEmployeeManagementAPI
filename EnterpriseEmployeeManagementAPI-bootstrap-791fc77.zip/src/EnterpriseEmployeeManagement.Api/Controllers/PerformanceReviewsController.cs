using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager,HR,Employee")]
[Route("api/v1/performance-reviews")]
public sealed class PerformanceReviewsController(IEnterpriseCrudService<PerformanceReviewDto> service)
    : EnterpriseCrudController<PerformanceReviewDto>(service);
