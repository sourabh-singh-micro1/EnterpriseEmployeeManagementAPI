using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager")]
[Route("api/v1/projects")]
public sealed class ProjectsController(IEnterpriseCrudService<ProjectDto> service)
    : EnterpriseCrudController<ProjectDto>(service);
