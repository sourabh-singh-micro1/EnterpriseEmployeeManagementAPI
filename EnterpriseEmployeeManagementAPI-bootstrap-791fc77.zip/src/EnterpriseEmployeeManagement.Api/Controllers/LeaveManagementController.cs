using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager,HR,Employee")]
[Route("api/v1/leave-requests")]
public sealed class LeaveManagementController(IEnterpriseCrudService<LeaveRequestDto> service)
    : EnterpriseCrudController<LeaveRequestDto>(service);
