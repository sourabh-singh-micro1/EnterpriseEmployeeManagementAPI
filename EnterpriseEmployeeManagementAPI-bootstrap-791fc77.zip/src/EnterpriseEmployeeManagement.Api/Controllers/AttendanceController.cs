using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager,HR,Employee")]
[Route("api/v1/attendance")]
public sealed class AttendanceController(IEnterpriseCrudService<AttendanceDto> service)
    : EnterpriseCrudController<AttendanceDto>(service);
