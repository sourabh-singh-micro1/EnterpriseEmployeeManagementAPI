using System.Security.Claims;
using EnterpriseEmployeeManagement.Application.Authentication;
using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Route("api/v1/auth")]
public sealed class AuthenticationController(IAuthenticationService authenticationService) : ControllerBase
{
    [AllowAnonymous]
    [HttpPost("login")]
    public Task<TokenResponse> LoginAsync(LoginRequest request, CancellationToken cancellationToken)
        => authenticationService.LoginAsync(request, cancellationToken);

    [Authorize(Roles = "Administrator,HR")]
    [HttpPost("register")]
    public Task<TokenResponse> RegisterAsync(RegisterUserRequest request, CancellationToken cancellationToken)
        => authenticationService.RegisterAsync(request, cancellationToken);

    [AllowAnonymous]
    [HttpPost("refresh")]
    public Task<TokenResponse> RefreshAsync(RefreshTokenRequest request, CancellationToken cancellationToken)
        => authenticationService.RefreshAsync(request, cancellationToken);

    [Authorize]
    [HttpPost("revoke")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    public async Task<IActionResult> RevokeAsync(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        await authenticationService.RevokeAsync(request, cancellationToken);
        return NoContent();
    }

    [Authorize]
    [HttpGet("me")]
    public Task<UserDto> GetMeAsync(CancellationToken cancellationToken)
    {
        Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier) ?? User.FindFirstValue("sub")!);
        return authenticationService.GetCurrentUserAsync(userId, cancellationToken);
    }
}
