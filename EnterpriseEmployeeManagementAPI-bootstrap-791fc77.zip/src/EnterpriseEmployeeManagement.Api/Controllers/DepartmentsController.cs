using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager,HR")]
[Route("api/v1/departments")]
public sealed class DepartmentsController(IEnterpriseCrudService<DepartmentDto> service)
    : EnterpriseCrudController<DepartmentDto>(service);
