using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator,Manager,HR")]
[Route("api/v1/employees")]
public sealed class EmployeesController(IEnterpriseCrudService<EmployeeDto> service)
    : EnterpriseCrudController<EmployeeDto>(service);
