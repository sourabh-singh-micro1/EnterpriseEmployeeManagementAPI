using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace EnterpriseEmployeeManagement.Api.Controllers;

[ApiController]
[Authorize(Roles = "Administrator")]
[Route("api/v1/roles")]
public sealed class RolesController(IEnterpriseCrudService<RoleDto> service)
    : EnterpriseCrudController<RoleDto>(service);
