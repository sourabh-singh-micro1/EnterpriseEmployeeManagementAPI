using System.Text.Json;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace EnterpriseEmployeeManagement.Api.Services;

public static class HealthResponseWriter
{
    public static Task WriteAsync(HttpContext context, HealthReport report)
    {
        context.Response.ContentType = "application/json";
        object payload = new
        {
            status = report.Status.ToString(),
            duration = report.TotalDuration,
            checks = report.Entries.Select(entry => new
            {
                name = entry.Key,
                status = entry.Value.Status.ToString(),
                description = entry.Value.Description,
                duration = entry.Value.Duration,
            }),
        };
        return context.Response.WriteAsync(JsonSerializer.Serialize(payload));
    }
}
