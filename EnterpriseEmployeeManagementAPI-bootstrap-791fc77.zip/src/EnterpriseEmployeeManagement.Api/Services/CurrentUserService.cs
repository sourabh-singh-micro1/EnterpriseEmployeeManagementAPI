using System.Security.Claims;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;

namespace EnterpriseEmployeeManagement.Api.Services;

public sealed class CurrentUserService(IHttpContextAccessor httpContextAccessor) : ICurrentUserService
{
    private ClaimsPrincipal? Principal => httpContextAccessor.HttpContext?.User;

    public Guid? UserId => ParseClaim(ClaimTypes.NameIdentifier);

    public Guid? EmployeeId => ParseClaim("employee_id");

    public string? Role => Principal?.FindFirstValue(ClaimTypes.Role) ?? Principal?.FindFirstValue("role");

    public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated == true;

    private Guid? ParseClaim(string claimType)
        => Guid.TryParse(Principal?.FindFirstValue(claimType), out Guid id) ? id : null;
}
