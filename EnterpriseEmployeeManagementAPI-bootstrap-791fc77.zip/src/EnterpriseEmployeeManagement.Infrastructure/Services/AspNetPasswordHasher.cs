using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.AspNetCore.Identity;

namespace EnterpriseEmployeeManagement.Infrastructure.Services;

public sealed class AspNetPasswordHasher : IPasswordHasher
{
    private readonly PasswordHasher<UserAccount> hasher = new();

    public string Hash(string password) => hasher.HashPassword(new UserAccount(), password);

    public bool Verify(string password, string passwordHash)
    {
        PasswordVerificationResult result = hasher.VerifyHashedPassword(new UserAccount(), passwordHash, password);
        return result is PasswordVerificationResult.Success or PasswordVerificationResult.SuccessRehashNeeded;
    }
}
