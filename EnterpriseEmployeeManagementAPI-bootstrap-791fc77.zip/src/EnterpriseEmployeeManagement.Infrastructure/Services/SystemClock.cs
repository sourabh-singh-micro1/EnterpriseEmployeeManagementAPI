using EnterpriseEmployeeManagement.Application.Common.Interfaces;

namespace EnterpriseEmployeeManagement.Infrastructure.Services;

public sealed class SystemClock : IClock
{
    public DateTimeOffset UtcNow => DateTimeOffset.UtcNow;

    public DateOnly Today => DateOnly.FromDateTime(DateTime.UtcNow);
}
