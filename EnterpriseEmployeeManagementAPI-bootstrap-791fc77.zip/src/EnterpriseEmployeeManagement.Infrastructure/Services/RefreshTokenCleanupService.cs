using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace EnterpriseEmployeeManagement.Infrastructure.Services;

#pragma warning disable CA1848, CA1873
public sealed class RefreshTokenCleanupService(
    IServiceScopeFactory scopeFactory,
    ILogger<RefreshTokenCleanupService> logger)
    : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using PeriodicTimer timer = new(TimeSpan.FromHours(6));
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            await CleanupAsync(stoppingToken);
        }
    }

    internal async Task CleanupAsync(CancellationToken cancellationToken)
    {
        using IServiceScope scope = scopeFactory.CreateScope();
        AppDbContext dbContext = scope.ServiceProvider.GetRequiredService<AppDbContext>();
        DateTimeOffset cutoff = DateTimeOffset.UtcNow.AddDays(-30);
        int deleted = await dbContext.Set<RefreshToken>()
            .Where(token => token.ExpiresAtUtc < cutoff || token.RevokedAtUtc < cutoff)
            .ExecuteDeleteAsync(cancellationToken);
        logger.LogInformation("Removed {DeletedTokenCount} expired refresh tokens", deleted);
    }
}
#pragma warning restore CA1848, CA1873
