using System.ComponentModel.DataAnnotations;

namespace EnterpriseEmployeeManagement.Infrastructure.Configuration;

public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    [Required]
    public string Issuer { get; init; } = string.Empty;

    [Required]
    public string Audience { get; init; } = string.Empty;

    [Required]
    [MinLength(32)]
    public string SigningKey { get; init; } = string.Empty;

    [Range(5, 120)]
    public int AccessTokenMinutes { get; init; } = 30;
}
