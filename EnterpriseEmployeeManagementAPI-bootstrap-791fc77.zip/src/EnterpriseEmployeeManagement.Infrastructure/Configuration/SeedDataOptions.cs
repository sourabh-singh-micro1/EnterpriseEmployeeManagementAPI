namespace EnterpriseEmployeeManagement.Infrastructure.Configuration;

public sealed class SeedDataOptions
{
    public const string SectionName = "SeedData";

    public bool Enabled { get; init; }

    public string AdministratorPassword { get; init; } = "ChangeMe!12345";
}
