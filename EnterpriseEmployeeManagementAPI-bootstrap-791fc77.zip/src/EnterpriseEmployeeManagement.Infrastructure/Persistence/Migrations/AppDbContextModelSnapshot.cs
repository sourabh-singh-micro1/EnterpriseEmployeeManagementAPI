using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;

#nullable disable

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Migrations;

[DbContext(typeof(AppDbContext))]
public sealed class AppDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.10");
        new EmployeeConfiguration().Configure(modelBuilder.Entity<Employee>());
        new DepartmentConfiguration().Configure(modelBuilder.Entity<Department>());
        new ProjectConfiguration().Configure(modelBuilder.Entity<Project>());
        new ProjectAssignmentConfiguration().Configure(modelBuilder.Entity<ProjectAssignment>());
        new AttendanceRecordConfiguration().Configure(modelBuilder.Entity<AttendanceRecord>());
        new LeaveRequestConfiguration().Configure(modelBuilder.Entity<LeaveRequest>());
        new LeaveBalanceConfiguration().Configure(modelBuilder.Entity<LeaveBalance>());
        new RoleConfiguration().Configure(modelBuilder.Entity<Role>());
        new UserAccountConfiguration().Configure(modelBuilder.Entity<UserAccount>());
        new RefreshTokenConfiguration().Configure(modelBuilder.Entity<RefreshToken>());
        new PayrollRecordConfiguration().Configure(modelBuilder.Entity<PayrollRecord>());
        new PerformanceReviewConfiguration().Configure(modelBuilder.Entity<PerformanceReview>());
    }
}
