using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Migrations;

public partial class OrganizationAndWorkforce : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Departments",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                Name = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                Code = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                CostCenter = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                ManagerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                AnnualBudget = table.Column<decimal>(type: "decimal(19,4)", precision: 19, scale: 4, nullable: false),
                IsActive = table.Column<bool>(type: "bit", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: false),
            },
            constraints: table => table.PrimaryKey("PK_Departments", x => x.Id));

        migrationBuilder.CreateTable(
            name: "Employees",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                EmployeeNumber = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                FirstName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                LastName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                Email = table.Column<string>(type: "nvarchar(254)", maxLength: 254, nullable: false),
                DepartmentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                ManagerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                HireDate = table.Column<DateOnly>(type: "date", nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                BaseSalary = table.Column<decimal>(type: "decimal(19,4)", precision: 19, scale: 4, nullable: false),
                Currency = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Employees", x => x.Id);
                table.ForeignKey("FK_Employees_Departments_DepartmentId", x => x.DepartmentId, "Departments", "Id", onDelete: ReferentialAction.Restrict);
                table.ForeignKey("FK_Employees_Employees_ManagerId", x => x.ManagerId, "Employees", "Id", onDelete: ReferentialAction.NoAction);
            });

        migrationBuilder.AddForeignKey(
            name: "FK_Departments_Employees_ManagerId",
            table: "Departments",
            column: "ManagerId",
            principalTable: "Employees",
            principalColumn: "Id",
            onDelete: ReferentialAction.NoAction);
        migrationBuilder.CreateIndex("IX_Departments_Code", "Departments", "Code", unique: true);
        migrationBuilder.CreateIndex("IX_Departments_ManagerId", "Departments", "ManagerId");
        migrationBuilder.CreateIndex("IX_Employees_DepartmentId", "Employees", "DepartmentId");
        migrationBuilder.CreateIndex("IX_Employees_ManagerId", "Employees", "ManagerId");
        migrationBuilder.CreateIndex("IX_Employees_EmployeeNumber", "Employees", "EmployeeNumber", unique: true);
        migrationBuilder.CreateIndex("IX_Employees_Email", "Employees", "Email", unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropForeignKey("FK_Departments_Employees_ManagerId", "Departments");
        migrationBuilder.DropTable("Employees");
        migrationBuilder.DropTable("Departments");
    }
}
