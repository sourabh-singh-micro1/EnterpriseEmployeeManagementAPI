using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable
#pragma warning disable CA1861

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Migrations;

public partial class PayrollAndPerformance : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "PayrollRecords",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                EmployeeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                PeriodStart = table.Column<DateOnly>(type: "date", nullable: false),
                PeriodEnd = table.Column<DateOnly>(type: "date", nullable: false),
                GrossPay = table.Column<decimal>(type: "decimal(19,4)", precision: 19, scale: 4, nullable: false),
                Deductions = table.Column<decimal>(type: "decimal(19,4)", precision: 19, scale: 4, nullable: false),
                NetPay = table.Column<decimal>(type: "decimal(19,4)", precision: 19, scale: 4, nullable: false),
                Currency = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_PayrollRecords", x => x.Id);
                table.ForeignKey("FK_PayrollRecords_Employees_EmployeeId", x => x.EmployeeId, "Employees", "Id", onDelete: ReferentialAction.Restrict);
            });

        migrationBuilder.CreateTable(
            name: "PerformanceReviews",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                EmployeeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                ReviewerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                ReviewPeriodStart = table.Column<DateOnly>(type: "date", nullable: false),
                ReviewPeriodEnd = table.Column<DateOnly>(type: "date", nullable: false),
                Score = table.Column<decimal>(type: "decimal(3,2)", precision: 3, scale: 2, nullable: false),
                Strengths = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                ImprovementAreas = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                Goals = table.Column<string>(type: "nvarchar(2000)", maxLength: 2000, nullable: false),
                Status = table.Column<int>(type: "int", nullable: false),
                CreatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                UpdatedAtUtc = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                RowVersion = table.Column<byte[]>(type: "rowversion", rowVersion: true, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_PerformanceReviews", x => x.Id);
                table.ForeignKey("FK_PerformanceReviews_Employees_EmployeeId", x => x.EmployeeId, "Employees", "Id", onDelete: ReferentialAction.Restrict);
                table.ForeignKey("FK_PerformanceReviews_Employees_ReviewerId", x => x.ReviewerId, "Employees", "Id", onDelete: ReferentialAction.NoAction);
            });

        migrationBuilder.CreateIndex("IX_PayrollRecords_EmployeeId_PeriodStart_PeriodEnd", "PayrollRecords", new[] { "EmployeeId", "PeriodStart", "PeriodEnd" }, unique: true);
        migrationBuilder.CreateIndex("IX_PerformanceReviews_ReviewerId", "PerformanceReviews", "ReviewerId");
        migrationBuilder.CreateIndex("IX_PerformanceReviews_EmployeeId_ReviewPeriodStart_ReviewPeriodEnd", "PerformanceReviews", new[] { "EmployeeId", "ReviewPeriodStart", "ReviewPeriodEnd" }, unique: true);
    }

    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable("PayrollRecords");
        migrationBuilder.DropTable("PerformanceReviews");
    }
}
