using EnterpriseEmployeeManagement.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Migrations;

[DbContext(typeof(AppDbContext))]
[Migration("202607240001_OrganizationAndWorkforce")]
public partial class OrganizationAndWorkforce
{
    protected override void BuildTargetModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.10");
    }
}
