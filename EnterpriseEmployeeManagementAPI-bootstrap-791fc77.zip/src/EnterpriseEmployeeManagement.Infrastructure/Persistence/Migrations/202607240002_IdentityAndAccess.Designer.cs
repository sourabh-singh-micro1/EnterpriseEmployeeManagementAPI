using EnterpriseEmployeeManagement.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Migrations;

[DbContext(typeof(AppDbContext))]
[Migration("202607240002_IdentityAndAccess")]
public partial class IdentityAndAccess
{
    protected override void BuildTargetModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "10.0.10");
    }
}
