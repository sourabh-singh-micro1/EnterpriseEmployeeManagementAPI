using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Common;
using Microsoft.EntityFrameworkCore;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence;

public sealed class EfRepository<TEntity>(AppDbContext dbContext) : IRepository<TEntity>
    where TEntity : BaseEntity
{
    private readonly DbSet<TEntity> entities = dbContext.Set<TEntity>();

    public IQueryable<TEntity> Query(bool asNoTracking = true)
        => asNoTracking ? entities.AsNoTracking() : entities;

    public ValueTask<TEntity?> FindAsync(Guid id, CancellationToken cancellationToken)
        => entities.FindAsync([id], cancellationToken);

    public async Task<TEntity?> GetByIdAsync(Guid id, CancellationToken cancellationToken)
        => await FindAsync(id, cancellationToken);

    public Task AddAsync(TEntity entity, CancellationToken cancellationToken)
        => entities.AddAsync(entity, cancellationToken).AsTask();

    public void Update(TEntity entity) => entities.Update(entity);

    public void Remove(TEntity entity) => entities.Remove(entity);

    public Task<int> CountAsync(IQueryable<TEntity> query, CancellationToken cancellationToken)
        => query.CountAsync(cancellationToken);

    public async Task<IReadOnlyList<TEntity>> ListAsync(
        IQueryable<TEntity> query,
        CancellationToken cancellationToken)
        => await query.ToListAsync(cancellationToken);

    public Task<bool> AnyAsync(IQueryable<TEntity> query, CancellationToken cancellationToken)
        => query.AnyAsync(cancellationToken);
}
