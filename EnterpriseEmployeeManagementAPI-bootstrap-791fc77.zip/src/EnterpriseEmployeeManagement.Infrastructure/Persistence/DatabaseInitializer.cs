using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using EnterpriseEmployeeManagement.Infrastructure.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence;

public sealed class DatabaseInitializer(
    AppDbContext dbContext,
    IPasswordHasher passwordHasher,
    IOptions<SeedDataOptions> seedOptions,
    IHostEnvironment environment)
{
    public async Task InitializeAsync(CancellationToken cancellationToken)
    {
        if (dbContext.Database.IsRelational())
        {
            await dbContext.Database.MigrateAsync(cancellationToken);
        }
        else
        {
            await dbContext.Database.EnsureCreatedAsync(cancellationToken);
        }

        if (!seedOptions.Value.Enabled || await dbContext.Roles.AnyAsync(cancellationToken))
        {
            return;
        }

        if (!environment.IsDevelopment()
            && seedOptions.Value.AdministratorPassword == "ChangeMe!12345")
        {
            throw new InvalidOperationException("The default seed administrator password is forbidden outside Development.");
        }

        Role[] roles =
        [
            new() { Name = RoleNames.Administrator, Description = "Full administrative access", IsSystemRole = true, Permissions = "*" },
            new() { Name = RoleNames.Manager, Description = "Team and project management", IsSystemRole = true, Permissions = "employees.read,projects.*,attendance.read,reviews.*" },
            new() { Name = RoleNames.HumanResources, Description = "Human-resources operations", IsSystemRole = true, Permissions = "employees.*,leave.*,payroll.*,reviews.*" },
            new() { Name = RoleNames.Employee, Description = "Employee self-service", IsSystemRole = true, Permissions = "profile.read,attendance.self,leave.self,reviews.self" },
        ];
        Department department = new()
        {
            Name = "Corporate Services",
            Code = "CORP",
            CostCenter = "CC-1000",
            AnnualBudget = 2_000_000,
        };
        Employee employee = new()
        {
            EmployeeNumber = "EMP-0001",
            FirstName = "System",
            LastName = "Administrator",
            Email = "admin@example.invalid",
            DepartmentId = department.Id,
            HireDate = DateOnly.FromDateTime(DateTime.UtcNow),
            Status = EmploymentStatus.Active,
            BaseSalary = 0,
        };
        UserAccount user = new()
        {
            Username = "admin",
            Email = employee.Email,
            EmployeeId = employee.Id,
            RoleId = roles[0].Id,
            PasswordHash = passwordHasher.Hash(seedOptions.Value.AdministratorPassword),
        };

        await dbContext.AddRangeAsync(roles, department, employee, user);
        await dbContext.SaveChangesAsync(cancellationToken);
    }
}
