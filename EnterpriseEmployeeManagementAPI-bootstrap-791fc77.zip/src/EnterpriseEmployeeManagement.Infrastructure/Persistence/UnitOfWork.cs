using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Common;
using Microsoft.Extensions.DependencyInjection;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence;

public sealed class UnitOfWork(AppDbContext dbContext, IServiceProvider serviceProvider) : IUnitOfWork
{
    public IRepository<TEntity> Repository<TEntity>()
        where TEntity : BaseEntity
        => serviceProvider.GetRequiredService<IRepository<TEntity>>();

    public Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        => dbContext.SaveChangesAsync(cancellationToken);
}
