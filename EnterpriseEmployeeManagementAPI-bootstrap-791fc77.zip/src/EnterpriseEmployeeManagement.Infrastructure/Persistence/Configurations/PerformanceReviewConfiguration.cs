using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class PerformanceReviewConfiguration : IEntityTypeConfiguration<PerformanceReview>
{
    public void Configure(EntityTypeBuilder<PerformanceReview> builder)
    {
        builder.ConfigureBase("PerformanceReviews");
        builder.Property(review => review.Score).HasPrecision(3, 2);
        builder.Property(review => review.Strengths).HasMaxLength(2_000).IsRequired();
        builder.Property(review => review.ImprovementAreas).HasMaxLength(2_000).IsRequired();
        builder.Property(review => review.Goals).HasMaxLength(2_000).IsRequired();
        builder.HasIndex(review => new { review.EmployeeId, review.ReviewPeriodStart, review.ReviewPeriodEnd }).IsUnique();
        builder.HasOne<Employee>().WithMany().HasForeignKey(review => review.EmployeeId).OnDelete(DeleteBehavior.Restrict);
        builder.HasOne<Employee>().WithMany().HasForeignKey(review => review.ReviewerId).OnDelete(DeleteBehavior.NoAction);
    }
}
