using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class RoleConfiguration : IEntityTypeConfiguration<Role>
{
    public void Configure(EntityTypeBuilder<Role> builder)
    {
        builder.ConfigureBase("Roles");
        builder.Property(role => role.Name).HasMaxLength(80).IsRequired();
        builder.Property(role => role.Description).HasMaxLength(500);
        builder.Property(role => role.Permissions).HasMaxLength(2_000).IsRequired();
        builder.HasIndex(role => role.Name).IsUnique();
    }
}
