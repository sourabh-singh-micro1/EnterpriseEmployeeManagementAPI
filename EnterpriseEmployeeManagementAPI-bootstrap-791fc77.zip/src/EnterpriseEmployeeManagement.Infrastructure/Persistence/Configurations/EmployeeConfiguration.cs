using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class EmployeeConfiguration : IEntityTypeConfiguration<Employee>
{
    public void Configure(EntityTypeBuilder<Employee> builder)
    {
        builder.ConfigureBase("Employees");
        builder.Property(employee => employee.EmployeeNumber).HasMaxLength(30).IsRequired();
        builder.Property(employee => employee.FirstName).HasMaxLength(100).IsRequired();
        builder.Property(employee => employee.LastName).HasMaxLength(100).IsRequired();
        builder.Property(employee => employee.Email).HasMaxLength(254).IsRequired();
        builder.Property(employee => employee.BaseSalary).HasPrecision(19, 4);
        builder.Property(employee => employee.Currency).HasMaxLength(3).IsRequired();
        builder.HasIndex(employee => employee.EmployeeNumber).IsUnique();
        builder.HasIndex(employee => employee.Email).IsUnique();
        builder.HasOne<Department>().WithMany().HasForeignKey(employee => employee.DepartmentId).OnDelete(DeleteBehavior.Restrict);
        builder.HasOne<Employee>().WithMany().HasForeignKey(employee => employee.ManagerId).OnDelete(DeleteBehavior.NoAction);
    }
}
