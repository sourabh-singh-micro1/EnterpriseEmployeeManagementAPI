using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class ProjectConfiguration : IEntityTypeConfiguration<Project>
{
    public void Configure(EntityTypeBuilder<Project> builder)
    {
        builder.ConfigureBase("Projects");
        builder.Property(project => project.Name).HasMaxLength(180).IsRequired();
        builder.Property(project => project.Code).HasMaxLength(30).IsRequired();
        builder.Property(project => project.Budget).HasPrecision(19, 4);
        builder.HasIndex(project => project.Code).IsUnique();
        builder.HasOne<Department>().WithMany().HasForeignKey(project => project.DepartmentId).OnDelete(DeleteBehavior.Restrict);
    }
}
