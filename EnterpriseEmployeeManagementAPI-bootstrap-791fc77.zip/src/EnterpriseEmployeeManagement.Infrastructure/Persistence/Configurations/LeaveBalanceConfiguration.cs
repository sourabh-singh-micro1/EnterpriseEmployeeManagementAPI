using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class LeaveBalanceConfiguration : IEntityTypeConfiguration<LeaveBalance>
{
    public void Configure(EntityTypeBuilder<LeaveBalance> builder)
    {
        builder.ConfigureBase("LeaveBalances");
        builder.Property(balance => balance.EntitledDays).HasPrecision(6, 2);
        builder.Property(balance => balance.UsedDays).HasPrecision(6, 2);
        builder.Ignore(balance => balance.RemainingDays);
        builder.HasIndex(balance => new { balance.EmployeeId, balance.Year, balance.LeaveType }).IsUnique();
        builder.HasOne<Employee>().WithMany().HasForeignKey(balance => balance.EmployeeId).OnDelete(DeleteBehavior.Cascade);
    }
}
