using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class LeaveRequestConfiguration : IEntityTypeConfiguration<LeaveRequest>
{
    public void Configure(EntityTypeBuilder<LeaveRequest> builder)
    {
        builder.ConfigureBase("LeaveRequests");
        builder.Property(request => request.Reason).HasMaxLength(1_000).IsRequired();
        builder.Property(request => request.DecisionNotes).HasMaxLength(1_000);
        builder.HasIndex(request => new { request.EmployeeId, request.StartDate, request.EndDate });
        builder.HasOne<Employee>().WithMany().HasForeignKey(request => request.EmployeeId).OnDelete(DeleteBehavior.Restrict);
        builder.HasOne<Employee>().WithMany().HasForeignKey(request => request.ApproverId).OnDelete(DeleteBehavior.NoAction);
    }
}
