using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class AttendanceRecordConfiguration : IEntityTypeConfiguration<AttendanceRecord>
{
    public void Configure(EntityTypeBuilder<AttendanceRecord> builder)
    {
        builder.ConfigureBase("AttendanceRecords");
        builder.Property(record => record.Notes).HasMaxLength(500);
        builder.HasIndex(record => new { record.EmployeeId, record.WorkDate }).IsUnique();
        builder.HasOne<Employee>().WithMany().HasForeignKey(record => record.EmployeeId).OnDelete(DeleteBehavior.Restrict);
    }
}
