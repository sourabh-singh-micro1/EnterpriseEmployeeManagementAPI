using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class ProjectAssignmentConfiguration : IEntityTypeConfiguration<ProjectAssignment>
{
    public void Configure(EntityTypeBuilder<ProjectAssignment> builder)
    {
        builder.ConfigureBase("ProjectAssignments");
        builder.Property(assignment => assignment.AllocationPercent).HasPrecision(5, 2);
        builder.HasIndex(assignment => new { assignment.ProjectId, assignment.EmployeeId, assignment.AssignedFrom }).IsUnique();
        builder.HasOne<Project>().WithMany().HasForeignKey(assignment => assignment.ProjectId).OnDelete(DeleteBehavior.Cascade);
        builder.HasOne<Employee>().WithMany().HasForeignKey(assignment => assignment.EmployeeId).OnDelete(DeleteBehavior.Restrict);
    }
}
