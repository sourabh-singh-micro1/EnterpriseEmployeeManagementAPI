using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class PayrollRecordConfiguration : IEntityTypeConfiguration<PayrollRecord>
{
    public void Configure(EntityTypeBuilder<PayrollRecord> builder)
    {
        builder.ConfigureBase("PayrollRecords");
        builder.Property(record => record.GrossPay).HasPrecision(19, 4);
        builder.Property(record => record.Deductions).HasPrecision(19, 4);
        builder.Property(record => record.NetPay).HasPrecision(19, 4);
        builder.Property(record => record.Currency).HasMaxLength(3).IsRequired();
        builder.HasIndex(record => new { record.EmployeeId, record.PeriodStart, record.PeriodEnd }).IsUnique();
        builder.HasOne<Employee>().WithMany().HasForeignKey(record => record.EmployeeId).OnDelete(DeleteBehavior.Restrict);
    }
}
