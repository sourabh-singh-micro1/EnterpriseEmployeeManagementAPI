using EnterpriseEmployeeManagement.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EnterpriseEmployeeManagement.Infrastructure.Persistence.Configurations;

public sealed class DepartmentConfiguration : IEntityTypeConfiguration<Department>
{
    public void Configure(EntityTypeBuilder<Department> builder)
    {
        builder.ConfigureBase("Departments");
        builder.Property(department => department.Name).HasMaxLength(150).IsRequired();
        builder.Property(department => department.Code).HasMaxLength(20).IsRequired();
        builder.Property(department => department.CostCenter).HasMaxLength(30).IsRequired();
        builder.Property(department => department.AnnualBudget).HasPrecision(19, 4);
        builder.HasIndex(department => department.Code).IsUnique();
        builder.HasOne<Employee>().WithMany().HasForeignKey(department => department.ManagerId).OnDelete(DeleteBehavior.NoAction);
    }
}
