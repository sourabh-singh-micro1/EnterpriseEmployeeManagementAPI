using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.ValueObjects;

namespace EnterpriseEmployeeManagement.Domain.Services;

public static class PayrollCalculator
{
    public static Money CalculateNetPay(decimal basePay, decimal allowances, decimal deductions, string currency)
    {
        if (deductions > basePay + allowances)
        {
            throw new DomainException("Deductions cannot exceed gross pay.");
        }

        return new Money(basePay + allowances - deductions, currency);
    }
}
