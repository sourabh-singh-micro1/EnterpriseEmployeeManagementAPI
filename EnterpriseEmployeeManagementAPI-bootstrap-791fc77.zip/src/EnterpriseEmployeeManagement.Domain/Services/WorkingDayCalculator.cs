namespace EnterpriseEmployeeManagement.Domain.Services;

public static class WorkingDayCalculator
{
    public static int CountWorkingDays(DateOnly start, DateOnly end)
    {
        int count = 0;
        for (DateOnly date = start; date <= end; date = date.AddDays(1))
        {
            if (date.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday)
            {
                count++;
            }
        }

        return count;
    }
}
