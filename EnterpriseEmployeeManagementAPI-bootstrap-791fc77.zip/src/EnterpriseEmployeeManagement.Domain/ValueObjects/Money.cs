using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Domain.ValueObjects;

public readonly record struct Money
{
    public Money(decimal amount, string currency)
    {
        if (amount < 0)
        {
            throw new DomainException("Money cannot be negative.");
        }

        Amount = decimal.Round(amount, 2, MidpointRounding.ToEven);
        Currency = string.IsNullOrWhiteSpace(currency) ? "USD" : currency.ToUpperInvariant();
    }

    public decimal Amount { get; }

    public string Currency { get; }
}
