using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Domain.ValueObjects;

public readonly record struct DateRange
{
    public DateRange(DateOnly start, DateOnly end)
    {
        if (end < start)
        {
            throw new DomainException("The end date must be on or after the start date.");
        }

        Start = start;
        End = end;
    }

    public DateOnly Start { get; }

    public DateOnly End { get; }

    public int InclusiveDays => End.DayNumber - Start.DayNumber + 1;

    public bool Overlaps(DateRange other) => Start <= other.End && other.Start <= End;
}
