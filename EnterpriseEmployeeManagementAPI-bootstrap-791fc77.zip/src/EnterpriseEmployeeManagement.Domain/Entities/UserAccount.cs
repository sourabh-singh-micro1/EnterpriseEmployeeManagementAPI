using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class UserAccount : BaseEntity
{
    public string Username { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string PasswordHash { get; set; } = string.Empty;

    public Guid EmployeeId { get; set; }

    public Guid RoleId { get; set; }

    public bool IsActive { get; set; } = true;

    public bool IsLocked { get; set; }

    public int FailedLoginAttempts { get; set; }

    public DateTimeOffset? LastLoginUtc { get; set; }
}
