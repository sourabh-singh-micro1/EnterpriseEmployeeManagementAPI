using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class LeaveBalance : BaseEntity
{
    public Guid EmployeeId { get; set; }

    public int Year { get; set; }

    public LeaveType LeaveType { get; set; }

    public decimal EntitledDays { get; set; }

    public decimal UsedDays { get; set; }

    public decimal RemainingDays => EntitledDays - UsedDays;
}
