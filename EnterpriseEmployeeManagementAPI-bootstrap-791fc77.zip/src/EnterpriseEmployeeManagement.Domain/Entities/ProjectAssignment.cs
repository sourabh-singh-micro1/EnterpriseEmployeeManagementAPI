using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class ProjectAssignment : BaseEntity
{
    public Guid ProjectId { get; set; }

    public Guid EmployeeId { get; set; }

    public AssignmentRole Role { get; set; }

    public decimal AllocationPercent { get; set; }

    public DateOnly AssignedFrom { get; set; }

    public DateOnly? AssignedUntil { get; set; }
}
