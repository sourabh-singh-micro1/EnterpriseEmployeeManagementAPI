using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class AttendanceRecord : BaseEntity
{
    public Guid EmployeeId { get; set; }

    public DateOnly WorkDate { get; set; }

    public DateTimeOffset? CheckInUtc { get; set; }

    public DateTimeOffset? CheckOutUtc { get; set; }

    public int WorkMinutes { get; set; }

    public AttendanceStatus Status { get; set; }

    public string Notes { get; set; } = string.Empty;
}
