using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class PayrollRecord : BaseEntity
{
    public Guid EmployeeId { get; set; }

    public DateOnly PeriodStart { get; set; }

    public DateOnly PeriodEnd { get; set; }

    public decimal GrossPay { get; set; }

    public decimal Deductions { get; set; }

    public decimal NetPay { get; set; }

    public string Currency { get; set; } = "USD";

    public PayrollStatus Status { get; set; } = PayrollStatus.Draft;
}
