using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Domain.Entities;

public sealed class Department : BaseEntity
{
    public string Name { get; set; } = string.Empty;

    public string Code { get; set; } = string.Empty;

    public string CostCenter { get; set; } = string.Empty;

    public Guid? ManagerId { get; set; }

    public decimal AnnualBudget { get; set; }

    public bool IsActive { get; set; } = true;
}
