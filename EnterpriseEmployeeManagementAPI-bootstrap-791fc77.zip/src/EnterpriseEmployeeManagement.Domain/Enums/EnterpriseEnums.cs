namespace EnterpriseEmployeeManagement.Domain.Enums;

public enum EmploymentStatus
{
    Active = 1,
    OnLeave = 2,
    Suspended = 3,
    Terminated = 4,
}

public enum ProjectStatus
{
    Planned = 1,
    Active = 2,
    OnHold = 3,
    Completed = 4,
    Cancelled = 5,
}

public enum AttendanceStatus
{
    Present = 1,
    Remote = 2,
    Late = 3,
    Absent = 4,
    Holiday = 5,
}

public enum LeaveType
{
    Annual = 1,
    Sick = 2,
    Parental = 3,
    Bereavement = 4,
    Unpaid = 5,
}

public enum ApprovalStatus
{
    Pending = 1,
    Approved = 2,
    Rejected = 3,
    Cancelled = 4,
}

public enum PayrollStatus
{
    Draft = 1,
    Calculated = 2,
    Approved = 3,
    Paid = 4,
    Voided = 5,
}

public enum ReviewStatus
{
    Draft = 1,
    Submitted = 2,
    Acknowledged = 3,
    Disputed = 4,
    Closed = 5,
}

public enum AssignmentRole
{
    Contributor = 1,
    Lead = 2,
    Sponsor = 3,
}
