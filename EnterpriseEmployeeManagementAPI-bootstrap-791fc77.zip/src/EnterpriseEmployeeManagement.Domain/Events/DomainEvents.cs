namespace EnterpriseEmployeeManagement.Domain.Events;

public sealed record EmployeeHiredEvent(Guid EmployeeId, string EmployeeNumber, DateTimeOffset OccurredAtUtc);

public sealed record LeaveApprovedEvent(Guid LeaveRequestId, Guid EmployeeId, decimal Days, DateTimeOffset OccurredAtUtc);

public sealed record PayrollFinalizedEvent(Guid PayrollRecordId, Guid EmployeeId, decimal NetPay, DateTimeOffset OccurredAtUtc);
