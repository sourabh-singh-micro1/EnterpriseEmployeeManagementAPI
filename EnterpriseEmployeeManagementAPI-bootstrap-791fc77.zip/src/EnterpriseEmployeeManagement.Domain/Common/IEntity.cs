namespace EnterpriseEmployeeManagement.Domain.Common;

public interface IEntity
{
    Guid Id { get; set; }
}
