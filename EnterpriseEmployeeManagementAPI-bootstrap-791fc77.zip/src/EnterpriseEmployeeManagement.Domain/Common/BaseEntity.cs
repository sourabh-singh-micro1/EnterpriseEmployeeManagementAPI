namespace EnterpriseEmployeeManagement.Domain.Common;

public abstract class BaseEntity : IEntity, IAuditableEntity
{
    public Guid Id { get; set; } = Guid.NewGuid();

    public DateTimeOffset CreatedAtUtc { get; set; }

    public DateTimeOffset? UpdatedAtUtc { get; set; }

    public byte[] RowVersion { get; set; } = [];
}
