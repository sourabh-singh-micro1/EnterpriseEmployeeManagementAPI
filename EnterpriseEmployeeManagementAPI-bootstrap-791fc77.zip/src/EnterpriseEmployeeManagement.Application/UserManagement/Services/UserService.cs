using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using EnterpriseEmployeeManagement.Domain.Common;
using EnterpriseEmployeeManagement.Domain.Entities;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.UserManagement.Services;

public sealed class UserService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<UserDto> validator,
    IPasswordHasher passwordHasher)
    : EnterpriseCrudService<UserAccount, UserDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(UserDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override Task ValidateUpdateAsync(UserAccount entity, UserDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override void AfterMapForCreate(UserAccount entity, UserDto dto)
    {
        entity.PasswordHash = passwordHasher.Hash(dto.Password!);
    }

    protected override void AfterMapForUpdate(UserAccount entity, UserDto dto)
    {
        if (!string.IsNullOrWhiteSpace(dto.Password))
        {
            entity.PasswordHash = passwordHasher.Hash(dto.Password);
            entity.FailedLoginAttempts = 0;
            entity.IsLocked = false;
        }
    }

    protected override async Task ValidateDeleteAsync(UserAccount entity, CancellationToken cancellationToken)
    {
        Role role = await UnitOfWork.Repository<Role>().GetByIdAsync(entity.RoleId, cancellationToken)
            ?? throw new BusinessRuleException("The user's role no longer exists.");
        if (role.Name == RoleNames.Administrator)
        {
            IRepository<UserAccount> users = UnitOfWork.Repository<UserAccount>();
            int activeAdmins = await users.CountAsync(
                users.Query().Where(user => user.RoleId == role.Id && user.IsActive && user.Id != entity.Id),
                cancellationToken);
            if (activeAdmins == 0)
            {
                throw new BusinessRuleException("The final active administrator cannot be deleted.");
            }
        }
    }

    private async Task ValidateRulesAsync(UserDto dto, CancellationToken cancellationToken)
    {
        IRepository<UserAccount> users = UnitOfWork.Repository<UserAccount>();
        if (await users.AnyAsync(
            users.Query().Where(user =>
                user.Id != dto.Id && (user.Username == dto.Username || user.Email == dto.Email)),
            cancellationToken))
        {
            throw new ConflictException("Username and email must be unique.");
        }

        if (await UnitOfWork.Repository<Employee>().GetByIdAsync(dto.EmployeeId, cancellationToken) is null)
        {
            throw new BusinessRuleException("A user account must be linked to an employee.");
        }

        if (await UnitOfWork.Repository<Role>().GetByIdAsync(dto.RoleId, cancellationToken) is null)
        {
            throw new BusinessRuleException("A user account must have an existing role.");
        }
    }
}
