using EnterpriseEmployeeManagement.Application.Common.Interfaces;

namespace EnterpriseEmployeeManagement.Application.UserManagement.Dtos;

public sealed class UserDto : IResourceDto
{
    public Guid Id { get; set; }

    public string Username { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public string? Password { get; set; }

    public Guid EmployeeId { get; set; }

    public Guid RoleId { get; set; }

    public bool IsActive { get; set; } = true;

    public bool IsLocked { get; set; }

    public DateTimeOffset? LastLoginUtc { get; set; }
}
