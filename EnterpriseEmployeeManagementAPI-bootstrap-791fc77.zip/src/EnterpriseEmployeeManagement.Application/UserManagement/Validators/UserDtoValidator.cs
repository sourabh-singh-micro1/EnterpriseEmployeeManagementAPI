using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.UserManagement.Validators;

public sealed class UserDtoValidator : AbstractValidator<UserDto>
{
    public UserDtoValidator()
    {
        RuleFor(x => x.Username).NotEmpty().MinimumLength(4).MaximumLength(80).Matches("^[A-Za-z0-9._-]+$");
        RuleFor(x => x.Email).NotEmpty().EmailAddress().MaximumLength(254);
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.RoleId).NotEmpty();
        RuleFor(x => x.Password)
            .MinimumLength(12)
            .Matches("[A-Z]").WithMessage("Password must contain an uppercase character.")
            .Matches("[a-z]").WithMessage("Password must contain a lowercase character.")
            .Matches("[0-9]").WithMessage("Password must contain a number.")
            .Matches("[^A-Za-z0-9]").WithMessage("Password must contain a symbol.")
            .When(x => x.Id == Guid.Empty || !string.IsNullOrWhiteSpace(x.Password));
    }
}
