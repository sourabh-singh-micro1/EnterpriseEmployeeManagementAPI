using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using EnterpriseEmployeeManagement.Domain.ValueObjects;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.LeaveManagement.Services;

public sealed class LeaveRequestService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<LeaveRequestDto> validator)
    : EnterpriseCrudService<LeaveRequest, LeaveRequestDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(LeaveRequestDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(
        LeaveRequest entity,
        LeaveRequestDto dto,
        CancellationToken cancellationToken)
    {
        if (entity.Status == ApprovalStatus.Approved && dto.Status == ApprovalStatus.Pending)
        {
            throw new BusinessRuleException("Approved leave cannot return to pending.");
        }

        await ValidateRulesAsync(dto, cancellationToken);
    }

    protected override Task ValidateDeleteAsync(LeaveRequest entity, CancellationToken cancellationToken)
    {
        if (entity.Status == ApprovalStatus.Approved)
        {
            throw new BusinessRuleException("Approved leave must be cancelled, not deleted.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateRulesAsync(LeaveRequestDto dto, CancellationToken cancellationToken)
    {
        DateRange requested = new(dto.StartDate, dto.EndDate);
        if (requested.InclusiveDays > 45)
        {
            throw new BusinessRuleException("A single leave request cannot exceed 45 calendar days.");
        }

        IRepository<LeaveRequest> requests = UnitOfWork.Repository<LeaveRequest>();
        bool overlaps = await requests.AnyAsync(
            requests.Query().Where(request =>
                request.Id != dto.Id
                && request.EmployeeId == dto.EmployeeId
                && request.Status != ApprovalStatus.Cancelled
                && request.Status != ApprovalStatus.Rejected
                && request.StartDate <= dto.EndDate
                && dto.StartDate <= request.EndDate),
            cancellationToken);
        if (overlaps)
        {
            throw new ConflictException("The leave request overlaps another pending or approved request.");
        }

        IRepository<LeaveBalance> balances = UnitOfWork.Repository<LeaveBalance>();
        IReadOnlyList<LeaveBalance> available = await balances.ListAsync(
            balances.Query().Where(balance =>
                balance.EmployeeId == dto.EmployeeId
                && balance.Year == dto.StartDate.Year
                && balance.LeaveType == dto.LeaveType),
            cancellationToken);
        LeaveBalance? balance = available.SingleOrDefault();
        if (dto.LeaveType != LeaveType.Unpaid && balance is not null && balance.RemainingDays < requested.InclusiveDays)
        {
            throw new BusinessRuleException("The employee has insufficient leave balance.");
        }
    }
}
