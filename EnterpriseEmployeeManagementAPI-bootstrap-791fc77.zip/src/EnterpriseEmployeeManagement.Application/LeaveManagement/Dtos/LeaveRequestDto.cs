using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;

public sealed class LeaveRequestDto : IResourceDto
{
    public Guid Id { get; set; }

    public Guid EmployeeId { get; set; }

    public LeaveType LeaveType { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }

    public string Reason { get; set; } = string.Empty;

    public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;

    public Guid? ApproverId { get; set; }

    public string DecisionNotes { get; set; } = string.Empty;
}
