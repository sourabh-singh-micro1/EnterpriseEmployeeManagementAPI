using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.LeaveManagement.Validators;

public sealed class LeaveRequestDtoValidator : AbstractValidator<LeaveRequestDto>
{
    public LeaveRequestDtoValidator()
    {
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.StartDate).NotEmpty();
        RuleFor(x => x.EndDate).GreaterThanOrEqualTo(x => x.StartDate);
        RuleFor(x => x.Reason).NotEmpty().MaximumLength(1_000);
        RuleFor(x => x.DecisionNotes).MaximumLength(1_000);
    }
}
