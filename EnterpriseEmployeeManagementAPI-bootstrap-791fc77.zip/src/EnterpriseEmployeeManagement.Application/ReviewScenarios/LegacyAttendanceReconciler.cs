namespace EnterpriseEmployeeManagement.Application.ReviewScenarios;

public sealed class LegacyAttendanceReconciler
{
#pragma warning disable CA1031, CA1822
    public bool TryReconcile(Action reconciliation)
    {
        try
        {
            reconciliation();
            return true;
        }
        catch
        {
            return false;
        }
    }
#pragma warning restore CA1031, CA1822
}
