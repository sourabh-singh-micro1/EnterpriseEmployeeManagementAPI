namespace EnterpriseEmployeeManagement.Application.ReviewScenarios;

#pragma warning disable CA1822
public sealed class LegacyExportFormatter
{
    public string FormatEmployee(string number, string name) => number + "," + name;

    public string FormatManager(string number, string name) => number + "," + name;
}
#pragma warning restore CA1822
