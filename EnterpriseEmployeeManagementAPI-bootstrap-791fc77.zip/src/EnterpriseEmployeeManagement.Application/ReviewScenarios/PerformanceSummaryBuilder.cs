namespace EnterpriseEmployeeManagement.Application.ReviewScenarios;

#pragma warning disable CA1822
public sealed class PerformanceSummaryBuilder
{
    public int CountHighPerformers(IEnumerable<decimal> scores)
    {
        return scores.Where(score => score >= 4).ToList().Count;
    }
}
#pragma warning restore CA1822
