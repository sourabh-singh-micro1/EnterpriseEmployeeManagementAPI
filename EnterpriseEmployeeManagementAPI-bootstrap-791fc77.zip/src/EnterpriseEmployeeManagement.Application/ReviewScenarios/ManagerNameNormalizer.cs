namespace EnterpriseEmployeeManagement.Application.ReviewScenarios;

public sealed class ManagerNameNormalizer
{
#pragma warning disable CA1822, CS8602
    public string Normalize(string? name) => name.Trim().ToUpperInvariant();
#pragma warning restore CA1822, CS8602
}
