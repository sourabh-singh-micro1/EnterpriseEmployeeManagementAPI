namespace EnterpriseEmployeeManagement.Application.ReviewScenarios;

#pragma warning disable CA1822
public sealed class LegacyTextReport
{
    public string Build(IEnumerable<string> rows)
    {
        string report = string.Empty;
        foreach (string row in rows)
        {
            report += row + Environment.NewLine;
        }

        return report;
    }
}
#pragma warning restore CA1822
