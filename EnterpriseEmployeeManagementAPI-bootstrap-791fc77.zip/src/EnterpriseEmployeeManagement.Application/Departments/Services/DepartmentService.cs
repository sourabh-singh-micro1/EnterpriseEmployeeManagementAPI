using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Departments.Services;

public sealed class DepartmentService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<DepartmentDto> validator)
    : EnterpriseCrudService<Department, DepartmentDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(DepartmentDto dto, CancellationToken cancellationToken)
        => ValidateUniqueCodeAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(
        Department entity,
        DepartmentDto dto,
        CancellationToken cancellationToken)
    {
        await ValidateUniqueCodeAsync(dto, cancellationToken);
        if (entity.IsActive && !dto.IsActive)
        {
            IRepository<Employee> employees = UnitOfWork.Repository<Employee>();
            bool hasActiveEmployees = await employees.AnyAsync(
                employees.Query().Where(employee =>
                    employee.DepartmentId == entity.Id && employee.Status != EmploymentStatus.Terminated),
                cancellationToken);
            if (hasActiveEmployees)
            {
                throw new BusinessRuleException("Reassign or terminate active employees before deactivating a department.");
            }
        }
    }

    protected override async Task ValidateDeleteAsync(Department entity, CancellationToken cancellationToken)
    {
        IRepository<Employee> employees = UnitOfWork.Repository<Employee>();
        if (await employees.AnyAsync(employees.Query().Where(employee => employee.DepartmentId == entity.Id), cancellationToken))
        {
            throw new BusinessRuleException("Departments with employee history cannot be deleted; deactivate them instead.");
        }
    }

    private async Task ValidateUniqueCodeAsync(DepartmentDto dto, CancellationToken cancellationToken)
    {
        IRepository<Department> departments = UnitOfWork.Repository<Department>();
        if (await departments.AnyAsync(
            departments.Query().Where(department => department.Id != dto.Id && department.Code == dto.Code),
            cancellationToken))
        {
            throw new ConflictException("Department code must be unique.");
        }
    }
}
