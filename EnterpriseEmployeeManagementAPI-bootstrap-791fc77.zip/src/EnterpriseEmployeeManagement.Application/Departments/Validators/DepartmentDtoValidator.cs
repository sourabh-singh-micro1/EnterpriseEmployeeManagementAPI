using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Departments.Validators;

public sealed class DepartmentDtoValidator : AbstractValidator<DepartmentDto>
{
    public DepartmentDtoValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(150);
        RuleFor(x => x.Code).NotEmpty().MaximumLength(20).Matches("^[A-Z0-9-]+$");
        RuleFor(x => x.CostCenter).NotEmpty().MaximumLength(30);
        RuleFor(x => x.AnnualBudget).GreaterThanOrEqualTo(0);
    }
}
