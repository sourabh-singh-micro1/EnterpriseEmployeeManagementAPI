using EnterpriseEmployeeManagement.Application.Common.Interfaces;

namespace EnterpriseEmployeeManagement.Application.Departments.Dtos;

public sealed class DepartmentDto : IResourceDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Code { get; set; } = string.Empty;

    public string CostCenter { get; set; } = string.Empty;

    public Guid? ManagerId { get; set; }

    public decimal AnnualBudget { get; set; }

    public bool IsActive { get; set; } = true;
}
