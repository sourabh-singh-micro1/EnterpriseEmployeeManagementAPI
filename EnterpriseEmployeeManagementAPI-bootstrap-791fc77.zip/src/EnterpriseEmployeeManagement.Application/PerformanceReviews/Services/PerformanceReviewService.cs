using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.PerformanceReviews.Services;

public sealed class PerformanceReviewService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<PerformanceReviewDto> validator)
    : EnterpriseCrudService<PerformanceReview, PerformanceReviewDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(PerformanceReviewDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(
        PerformanceReview entity,
        PerformanceReviewDto dto,
        CancellationToken cancellationToken)
    {
        if (entity.Status == ReviewStatus.Closed)
        {
            throw new BusinessRuleException("Closed performance reviews are immutable.");
        }

        await ValidateRulesAsync(dto, cancellationToken);
    }

    protected override Task ValidateDeleteAsync(PerformanceReview entity, CancellationToken cancellationToken)
    {
        if (entity.Status != ReviewStatus.Draft)
        {
            throw new BusinessRuleException("Only draft performance reviews can be deleted.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateRulesAsync(PerformanceReviewDto dto, CancellationToken cancellationToken)
    {
        if (dto.EmployeeId == dto.ReviewerId)
        {
            throw new BusinessRuleException("Employees cannot review themselves.");
        }

        IRepository<PerformanceReview> reviews = UnitOfWork.Repository<PerformanceReview>();
        if (await reviews.AnyAsync(
            reviews.Query().Where(review =>
                review.Id != dto.Id
                && review.EmployeeId == dto.EmployeeId
                && review.ReviewPeriodStart == dto.ReviewPeriodStart
                && review.ReviewPeriodEnd == dto.ReviewPeriodEnd),
            cancellationToken))
        {
            throw new ConflictException("A review already exists for this employee and period.");
        }
    }
}
