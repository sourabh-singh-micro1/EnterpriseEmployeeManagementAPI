using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;

public sealed class PerformanceReviewDto : IResourceDto
{
    public Guid Id { get; set; }

    public Guid EmployeeId { get; set; }

    public Guid ReviewerId { get; set; }

    public DateOnly ReviewPeriodStart { get; set; }

    public DateOnly ReviewPeriodEnd { get; set; }

    public decimal Score { get; set; }

    public string Strengths { get; set; } = string.Empty;

    public string ImprovementAreas { get; set; } = string.Empty;

    public string Goals { get; set; } = string.Empty;

    public ReviewStatus Status { get; set; } = ReviewStatus.Draft;
}
