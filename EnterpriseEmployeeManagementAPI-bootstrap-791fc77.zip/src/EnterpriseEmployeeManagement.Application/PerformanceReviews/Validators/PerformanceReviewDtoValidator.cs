using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.PerformanceReviews.Validators;

public sealed class PerformanceReviewDtoValidator : AbstractValidator<PerformanceReviewDto>
{
    public PerformanceReviewDtoValidator()
    {
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.ReviewerId).NotEmpty().NotEqual(x => x.EmployeeId);
        RuleFor(x => x.ReviewPeriodEnd).GreaterThanOrEqualTo(x => x.ReviewPeriodStart);
        RuleFor(x => x.Score).InclusiveBetween(1, 5);
        RuleFor(x => x.Strengths).NotEmpty().MaximumLength(2_000);
        RuleFor(x => x.ImprovementAreas).NotEmpty().MaximumLength(2_000);
        RuleFor(x => x.Goals).NotEmpty().MaximumLength(2_000);
    }
}
