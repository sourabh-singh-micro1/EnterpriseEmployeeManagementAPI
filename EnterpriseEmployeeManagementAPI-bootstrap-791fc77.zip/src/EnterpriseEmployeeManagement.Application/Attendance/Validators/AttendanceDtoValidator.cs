using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Attendance.Validators;

public sealed class AttendanceDtoValidator : AbstractValidator<AttendanceDto>
{
    public AttendanceDtoValidator()
    {
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.WorkDate).NotEmpty();
        RuleFor(x => x.WorkMinutes).InclusiveBetween(0, 1_200);
        RuleFor(x => x.CheckOutUtc)
            .GreaterThan(x => x.CheckInUtc)
            .When(x => x.CheckInUtc.HasValue && x.CheckOutUtc.HasValue);
        RuleFor(x => x.Notes).MaximumLength(500);
    }
}
