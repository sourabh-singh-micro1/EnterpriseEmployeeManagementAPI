using AutoMapper;
using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Domain.Entities;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Attendance.Services;

public sealed class AttendanceService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<AttendanceDto> validator,
    IClock clock)
    : EnterpriseCrudService<AttendanceRecord, AttendanceDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(AttendanceDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override Task ValidateUpdateAsync(
        AttendanceRecord entity,
        AttendanceDto dto,
        CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    private async Task ValidateRulesAsync(AttendanceDto dto, CancellationToken cancellationToken)
    {
        if (dto.WorkDate > clock.Today)
        {
            throw new BusinessRuleException("Attendance cannot be recorded for a future date.");
        }

        if (dto.CheckInUtc.HasValue && dto.CheckOutUtc.HasValue)
        {
            double minutes = (dto.CheckOutUtc.Value - dto.CheckInUtc.Value).TotalMinutes;
            if (minutes > 1_200 || Math.Abs(minutes - dto.WorkMinutes) > 5)
            {
                throw new BusinessRuleException("Work minutes must match the recorded times and cannot exceed 20 hours.");
            }
        }

        if (await UnitOfWork.Repository<Employee>().GetByIdAsync(dto.EmployeeId, cancellationToken) is null)
        {
            throw new BusinessRuleException("Attendance requires an existing employee.");
        }

        IRepository<AttendanceRecord> records = UnitOfWork.Repository<AttendanceRecord>();
        if (await records.AnyAsync(
            records.Query().Where(record =>
                record.Id != dto.Id && record.EmployeeId == dto.EmployeeId && record.WorkDate == dto.WorkDate),
            cancellationToken))
        {
            throw new ConflictException("Only one attendance record per employee and work date is allowed.");
        }
    }
}
