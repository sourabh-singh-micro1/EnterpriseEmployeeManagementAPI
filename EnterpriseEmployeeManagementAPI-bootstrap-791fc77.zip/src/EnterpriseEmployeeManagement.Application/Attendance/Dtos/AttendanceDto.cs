using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Application.Attendance.Dtos;

public sealed class AttendanceDto : IResourceDto
{
    public Guid Id { get; set; }

    public Guid EmployeeId { get; set; }

    public DateOnly WorkDate { get; set; }

    public DateTimeOffset? CheckInUtc { get; set; }

    public DateTimeOffset? CheckOutUtc { get; set; }

    public int WorkMinutes { get; set; }

    public AttendanceStatus Status { get; set; }

    public string Notes { get; set; } = string.Empty;
}
