using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Projects.Services;

public sealed class ProjectService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<ProjectDto> validator)
    : EnterpriseCrudService<Project, ProjectDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(ProjectDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(Project entity, ProjectDto dto, CancellationToken cancellationToken)
    {
        if (entity.Status == ProjectStatus.Completed && dto.Status != ProjectStatus.Completed)
        {
            throw new BusinessRuleException("A completed project cannot be reopened through the standard update operation.");
        }

        await ValidateRulesAsync(dto, cancellationToken);
    }

    protected override Task ValidateDeleteAsync(Project entity, CancellationToken cancellationToken)
    {
        if (entity.Status is ProjectStatus.Active or ProjectStatus.Completed)
        {
            throw new BusinessRuleException("Active or completed projects must be retained for audit.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateRulesAsync(ProjectDto dto, CancellationToken cancellationToken)
    {
        Department? department = await UnitOfWork.Repository<Department>().GetByIdAsync(dto.DepartmentId, cancellationToken);
        if (department is null || !department.IsActive)
        {
            throw new BusinessRuleException("Projects require an active owning department.");
        }

        if (dto.Budget > department.AnnualBudget)
        {
            throw new BusinessRuleException("Project budget cannot exceed the department annual budget.");
        }

        IRepository<Project> projects = UnitOfWork.Repository<Project>();
        if (await projects.AnyAsync(
            projects.Query().Where(project => project.Id != dto.Id && project.Code == dto.Code),
            cancellationToken))
        {
            throw new ConflictException("Project code must be unique.");
        }
    }
}
