using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Projects.Validators;

public sealed class ProjectDtoValidator : AbstractValidator<ProjectDto>
{
    public ProjectDtoValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(180);
        RuleFor(x => x.Code).NotEmpty().MaximumLength(30).Matches("^[A-Z0-9-]+$");
        RuleFor(x => x.DepartmentId).NotEmpty();
        RuleFor(x => x.Budget).GreaterThanOrEqualTo(0);
        RuleFor(x => x.EndDate).GreaterThanOrEqualTo(x => x.StartDate);
    }
}
