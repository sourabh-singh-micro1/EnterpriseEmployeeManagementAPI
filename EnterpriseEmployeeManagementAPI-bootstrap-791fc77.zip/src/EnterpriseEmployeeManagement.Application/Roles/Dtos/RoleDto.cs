using EnterpriseEmployeeManagement.Application.Common.Interfaces;

namespace EnterpriseEmployeeManagement.Application.Roles.Dtos;

public sealed class RoleDto : IResourceDto
{
    public Guid Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public bool IsSystemRole { get; set; }

    public string Permissions { get; set; } = string.Empty;
}
