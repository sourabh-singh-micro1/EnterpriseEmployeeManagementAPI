using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Roles.Services;

public sealed class RoleService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<RoleDto> validator)
    : EnterpriseCrudService<Role, RoleDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(RoleDto dto, CancellationToken cancellationToken)
        => ValidateUniqueNameAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(Role entity, RoleDto dto, CancellationToken cancellationToken)
    {
        if (entity.IsSystemRole && !string.Equals(entity.Name, dto.Name, StringComparison.Ordinal))
        {
            throw new BusinessRuleException("System roles cannot be renamed.");
        }

        dto.IsSystemRole = entity.IsSystemRole;
        await ValidateUniqueNameAsync(dto, cancellationToken);
    }

    protected override Task ValidateDeleteAsync(Role entity, CancellationToken cancellationToken)
    {
        if (entity.IsSystemRole)
        {
            throw new BusinessRuleException("System roles cannot be deleted.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateUniqueNameAsync(RoleDto dto, CancellationToken cancellationToken)
    {
        IRepository<Role> roles = UnitOfWork.Repository<Role>();
        if (await roles.AnyAsync(roles.Query().Where(role => role.Id != dto.Id && role.Name == dto.Name), cancellationToken))
        {
            throw new ConflictException("Role name must be unique.");
        }
    }
}
