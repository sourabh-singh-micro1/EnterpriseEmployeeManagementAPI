using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Roles.Validators;

public sealed class RoleDtoValidator : AbstractValidator<RoleDto>
{
    public RoleDtoValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(80).Matches("^[A-Za-z][A-Za-z0-9 ]+$");
        RuleFor(x => x.Description).MaximumLength(500);
        RuleFor(x => x.Permissions).NotEmpty().MaximumLength(2_000);
    }
}
