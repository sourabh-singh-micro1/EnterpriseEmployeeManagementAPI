using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using EnterpriseEmployeeManagement.Application.Attendance.Services;
using EnterpriseEmployeeManagement.Application.Authentication;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Mappings;
using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using EnterpriseEmployeeManagement.Application.Departments.Services;
using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using EnterpriseEmployeeManagement.Application.Employees.Services;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Services;
using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using EnterpriseEmployeeManagement.Application.Payroll.Services;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Services;
using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using EnterpriseEmployeeManagement.Application.Projects.Services;
using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using EnterpriseEmployeeManagement.Application.Roles.Services;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using EnterpriseEmployeeManagement.Application.UserManagement.Services;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace EnterpriseEmployeeManagement.Application;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddAutoMapper(typeof(EnterpriseMappingProfile).Assembly);
        services.AddValidatorsFromAssemblyContaining<EnterpriseMappingProfile>();
        services.AddScoped<IEnterpriseCrudService<EmployeeDto>, EmployeeService>();
        services.AddScoped<IEnterpriseCrudService<DepartmentDto>, DepartmentService>();
        services.AddScoped<IEnterpriseCrudService<ProjectDto>, ProjectService>();
        services.AddScoped<IEnterpriseCrudService<AttendanceDto>, AttendanceService>();
        services.AddScoped<IEnterpriseCrudService<LeaveRequestDto>, LeaveRequestService>();
        services.AddScoped<IEnterpriseCrudService<RoleDto>, RoleService>();
        services.AddScoped<IEnterpriseCrudService<UserDto>, UserService>();
        services.AddScoped<IEnterpriseCrudService<PayrollDto>, PayrollService>();
        services.AddScoped<IEnterpriseCrudService<PerformanceReviewDto>, PerformanceReviewService>();
        services.AddScoped<IAuthenticationService, AuthenticationService>();
        return services;
    }
}
