using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;

namespace EnterpriseEmployeeManagement.Application.Authentication;

public interface IAuthenticationService
{
    Task<TokenResponse> LoginAsync(LoginRequest request, CancellationToken cancellationToken);

    Task<TokenResponse> RegisterAsync(RegisterUserRequest request, CancellationToken cancellationToken);

    Task<TokenResponse> RefreshAsync(RefreshTokenRequest request, CancellationToken cancellationToken);

    Task RevokeAsync(RefreshTokenRequest request, CancellationToken cancellationToken);

    Task<UserDto> GetCurrentUserAsync(Guid userId, CancellationToken cancellationToken);
}
