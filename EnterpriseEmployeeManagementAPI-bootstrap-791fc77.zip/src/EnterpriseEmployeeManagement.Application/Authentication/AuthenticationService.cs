using System.Security.Cryptography;
using System.Text;
using AutoMapper;
using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Models;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Authentication;

public sealed class AuthenticationService(
    IUnitOfWork unitOfWork,
    IPasswordHasher passwordHasher,
    ITokenService tokenService,
    IClock clock,
    IValidator<LoginRequest> loginValidator,
    IValidator<RegisterUserRequest> registerValidator,
    IMapper mapper)
    : IAuthenticationService
{
    public async Task<TokenResponse> LoginAsync(LoginRequest request, CancellationToken cancellationToken)
    {
        await loginValidator.ValidateAndThrowAsync(request, cancellationToken);
        UserAccount? user = await FindUserByNameAsync(request.Username, track: true, cancellationToken);
        if (user is null || !user.IsActive)
        {
            throw new AuthenticationException("Invalid username or password.");
        }

        if (user.IsLocked)
        {
            throw new AuthenticationException("The account is locked. Contact an administrator.");
        }

        if (!passwordHasher.Verify(request.Password, user.PasswordHash))
        {
            user.FailedLoginAttempts++;
            user.IsLocked = user.FailedLoginAttempts >= 5;
            unitOfWork.Repository<UserAccount>().Update(user);
            await unitOfWork.SaveChangesAsync(cancellationToken);
            throw new AuthenticationException("Invalid username or password.");
        }

        Role role = await unitOfWork.Repository<Role>().GetByIdAsync(user.RoleId, cancellationToken)
            ?? throw new AuthenticationException("The account has no valid role.");
        user.FailedLoginAttempts = 0;
        user.LastLoginUtc = clock.UtcNow;
        unitOfWork.Repository<UserAccount>().Update(user);
        IssuedTokenSet tokens = tokenService.Issue(user, role.Name);
        await StoreRefreshTokenAsync(user.Id, tokens, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return ToResponse(tokens);
    }

    public async Task<TokenResponse> RegisterAsync(RegisterUserRequest request, CancellationToken cancellationToken)
    {
        await registerValidator.ValidateAndThrowAsync(request, cancellationToken);
        if (await FindUserByNameAsync(request.Username, track: false, cancellationToken) is not null)
        {
            throw new ConflictException("Username already exists.");
        }

        IRepository<UserAccount> users = unitOfWork.Repository<UserAccount>();
        if (await users.AnyAsync(users.Query().Where(user => user.Email == request.Email), cancellationToken))
        {
            throw new ConflictException("Email already exists.");
        }

        if (await unitOfWork.Repository<Employee>().GetByIdAsync(request.EmployeeId, cancellationToken) is null)
        {
            throw new BusinessRuleException("Registration must be linked to an employee.");
        }

        Role role = await unitOfWork.Repository<Role>().GetByIdAsync(request.RoleId, cancellationToken)
            ?? throw new BusinessRuleException("Registration requires an existing role.");
        UserAccount user = new()
        {
            Username = request.Username,
            Email = request.Email,
            PasswordHash = passwordHasher.Hash(request.Password),
            EmployeeId = request.EmployeeId,
            RoleId = request.RoleId,
        };
        await users.AddAsync(user, cancellationToken);
        IssuedTokenSet tokens = tokenService.Issue(user, role.Name);
        await StoreRefreshTokenAsync(user.Id, tokens, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return ToResponse(tokens);
    }

    public async Task<TokenResponse> RefreshAsync(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        string hash = HashToken(request.RefreshToken);
        IRepository<RefreshToken> tokens = unitOfWork.Repository<RefreshToken>();
        IReadOnlyList<RefreshToken> matches = await tokens.ListAsync(
            tokens.Query(asNoTracking: false).Where(token => token.TokenHash == hash).Take(1),
            cancellationToken);
        RefreshToken existing = matches.SingleOrDefault()
            ?? throw new AuthenticationException("Refresh token is invalid.");
        if (!existing.IsActive(clock.UtcNow))
        {
            throw new AuthenticationException("Refresh token is expired or revoked.");
        }

        UserAccount user = await unitOfWork.Repository<UserAccount>().GetByIdAsync(existing.UserAccountId, cancellationToken)
            ?? throw new AuthenticationException("Refresh token user no longer exists.");
        Role role = await unitOfWork.Repository<Role>().GetByIdAsync(user.RoleId, cancellationToken)
            ?? throw new AuthenticationException("Refresh token user has no valid role.");
        IssuedTokenSet replacement = tokenService.Issue(user, role.Name);
        existing.RevokedAtUtc = clock.UtcNow;
        existing.ReplacedByTokenHash = replacement.RefreshTokenHash;
        tokens.Update(existing);
        await StoreRefreshTokenAsync(user.Id, replacement, cancellationToken);
        await unitOfWork.SaveChangesAsync(cancellationToken);
        return ToResponse(replacement);
    }

    public async Task RevokeAsync(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        string hash = HashToken(request.RefreshToken);
        IRepository<RefreshToken> tokens = unitOfWork.Repository<RefreshToken>();
        IReadOnlyList<RefreshToken> matches = await tokens.ListAsync(
            tokens.Query(asNoTracking: false).Where(token => token.TokenHash == hash).Take(1),
            cancellationToken);
        RefreshToken existing = matches.SingleOrDefault()
            ?? throw new NotFoundException(nameof(RefreshToken), "token");
        existing.RevokedAtUtc = clock.UtcNow;
        tokens.Update(existing);
        await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<UserDto> GetCurrentUserAsync(Guid userId, CancellationToken cancellationToken)
    {
        UserAccount user = await unitOfWork.Repository<UserAccount>().GetByIdAsync(userId, cancellationToken)
            ?? throw new NotFoundException(nameof(UserAccount), userId);
        return mapper.Map<UserDto>(user);
    }

    private async Task<UserAccount?> FindUserByNameAsync(
        string username,
        bool track,
        CancellationToken cancellationToken)
    {
        IRepository<UserAccount> users = unitOfWork.Repository<UserAccount>();
        IReadOnlyList<UserAccount> matches = await users.ListAsync(
            users.Query(asNoTracking: !track).Where(user => user.Username == username).Take(1),
            cancellationToken);
        return matches.SingleOrDefault();
    }

    private async Task StoreRefreshTokenAsync(
        Guid userId,
        IssuedTokenSet tokenSet,
        CancellationToken cancellationToken)
    {
        await unitOfWork.Repository<RefreshToken>().AddAsync(new RefreshToken
        {
            UserAccountId = userId,
            TokenHash = tokenSet.RefreshTokenHash,
            ExpiresAtUtc = tokenSet.ExpiresAtUtc.AddDays(7),
        }, cancellationToken);
    }

    private static TokenResponse ToResponse(IssuedTokenSet tokens)
        => new(tokens.AccessToken, tokens.RefreshToken, tokens.ExpiresAtUtc);

    private static string HashToken(string token)
        => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
}
