namespace EnterpriseEmployeeManagement.Application.Authentication.Dtos;

public sealed record LoginRequest(string Username, string Password);
