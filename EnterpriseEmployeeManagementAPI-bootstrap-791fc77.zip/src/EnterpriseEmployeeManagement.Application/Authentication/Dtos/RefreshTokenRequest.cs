namespace EnterpriseEmployeeManagement.Application.Authentication.Dtos;

public sealed record RefreshTokenRequest(string RefreshToken);
