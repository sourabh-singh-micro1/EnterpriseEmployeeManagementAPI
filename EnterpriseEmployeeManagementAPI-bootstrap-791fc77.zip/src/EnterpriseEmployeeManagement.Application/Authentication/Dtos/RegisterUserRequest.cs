namespace EnterpriseEmployeeManagement.Application.Authentication.Dtos;

public sealed record RegisterUserRequest(
    string Username,
    string Email,
    string Password,
    Guid EmployeeId,
    Guid RoleId);
