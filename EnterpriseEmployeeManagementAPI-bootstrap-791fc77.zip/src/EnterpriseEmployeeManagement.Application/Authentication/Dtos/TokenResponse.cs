namespace EnterpriseEmployeeManagement.Application.Authentication.Dtos;

public sealed record TokenResponse(
    string AccessToken,
    string RefreshToken,
    DateTimeOffset ExpiresAtUtc,
    string TokenType = "Bearer");
