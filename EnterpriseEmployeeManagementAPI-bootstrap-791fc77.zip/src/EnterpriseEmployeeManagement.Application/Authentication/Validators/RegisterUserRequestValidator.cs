using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Authentication.Validators;

public sealed class RegisterUserRequestValidator : AbstractValidator<RegisterUserRequest>
{
    public RegisterUserRequestValidator()
    {
        RuleFor(x => x.Username).NotEmpty().MinimumLength(4).MaximumLength(80);
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.Password).MinimumLength(12).Matches("[A-Z]").Matches("[a-z]").Matches("[0-9]").Matches("[^A-Za-z0-9]");
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.RoleId).NotEmpty();
    }
}
