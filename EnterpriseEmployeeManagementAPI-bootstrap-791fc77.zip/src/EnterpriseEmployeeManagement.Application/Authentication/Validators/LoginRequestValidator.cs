using EnterpriseEmployeeManagement.Application.Authentication.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Authentication.Validators;

public sealed class LoginRequestValidator : AbstractValidator<LoginRequest>
{
    public LoginRequestValidator()
    {
        RuleFor(x => x.Username).NotEmpty().MaximumLength(80);
        RuleFor(x => x.Password).NotEmpty().MaximumLength(200);
    }
}
