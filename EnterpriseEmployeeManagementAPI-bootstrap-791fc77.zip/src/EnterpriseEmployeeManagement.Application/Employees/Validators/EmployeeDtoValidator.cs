using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Employees.Validators;

public sealed class EmployeeDtoValidator : AbstractValidator<EmployeeDto>
{
    public EmployeeDtoValidator()
    {
        RuleFor(x => x.EmployeeNumber).NotEmpty().MaximumLength(30).Matches("^[A-Z0-9-]+$");
        RuleFor(x => x.FirstName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.LastName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.Email).NotEmpty().EmailAddress().MaximumLength(254);
        RuleFor(x => x.DepartmentId).NotEmpty();
        RuleFor(x => x.BaseSalary).GreaterThanOrEqualTo(0);
        RuleFor(x => x.Currency).NotEmpty().Length(3);
    }
}
