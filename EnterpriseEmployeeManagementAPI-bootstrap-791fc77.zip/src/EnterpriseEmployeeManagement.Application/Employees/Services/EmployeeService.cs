using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Employees.Services;

public sealed class EmployeeService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<EmployeeDto> validator,
    IClock clock)
    : EnterpriseCrudService<Employee, EmployeeDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(EmployeeDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override Task ValidateUpdateAsync(Employee entity, EmployeeDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override Task ValidateDeleteAsync(Employee entity, CancellationToken cancellationToken)
    {
        if (entity.Status != Domain.Enums.EmploymentStatus.Terminated)
        {
            throw new BusinessRuleException("An employee must be terminated before the record can be deleted.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateRulesAsync(EmployeeDto dto, CancellationToken cancellationToken)
    {
        IRepository<Employee> employees = UnitOfWork.Repository<Employee>();
        bool duplicate = await employees.AnyAsync(
            employees.Query().Where(employee =>
                employee.Id != dto.Id
                && (employee.EmployeeNumber == dto.EmployeeNumber || employee.Email == dto.Email)),
            cancellationToken);
        if (duplicate)
        {
            throw new ConflictException("Employee number and email must be unique.");
        }

        Department? department = await UnitOfWork.Repository<Department>().GetByIdAsync(dto.DepartmentId, cancellationToken);
        if (department is null || !department.IsActive)
        {
            throw new BusinessRuleException("Employees must belong to an active department.");
        }

        if (dto.ManagerId == dto.Id && dto.Id != Guid.Empty)
        {
            throw new BusinessRuleException("An employee cannot manage themselves.");
        }

        if (dto.HireDate > clock.Today)
        {
            throw new BusinessRuleException("Hire date cannot be in the future.");
        }
    }
}
