using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Application.Employees.Dtos;

public sealed class EmployeeDto : IResourceDto
{
    public Guid Id { get; set; }

    public string EmployeeNumber { get; set; } = string.Empty;

    public string FirstName { get; set; } = string.Empty;

    public string LastName { get; set; } = string.Empty;

    public string Email { get; set; } = string.Empty;

    public Guid DepartmentId { get; set; }

    public Guid? ManagerId { get; set; }

    public DateOnly HireDate { get; set; }

    public EmploymentStatus Status { get; set; } = EmploymentStatus.Active;

    public decimal BaseSalary { get; set; }

    public string Currency { get; set; } = "USD";
}
