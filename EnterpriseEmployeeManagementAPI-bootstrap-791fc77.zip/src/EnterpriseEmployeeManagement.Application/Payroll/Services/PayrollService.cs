using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Services;
using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;
using EnterpriseEmployeeManagement.Domain.Enums;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Payroll.Services;

public sealed class PayrollService(
    IUnitOfWork unitOfWork,
    IMapper mapper,
    IValidator<PayrollDto> validator,
    IClock clock)
    : EnterpriseCrudService<PayrollRecord, PayrollDto>(unitOfWork, mapper, validator)
{
    protected override Task ValidateCreateAsync(PayrollDto dto, CancellationToken cancellationToken)
        => ValidateRulesAsync(dto, cancellationToken);

    protected override async Task ValidateUpdateAsync(
        PayrollRecord entity,
        PayrollDto dto,
        CancellationToken cancellationToken)
    {
        if (entity.Status is PayrollStatus.Paid or PayrollStatus.Voided)
        {
            throw new BusinessRuleException("Paid or voided payroll records are immutable.");
        }

        await ValidateRulesAsync(dto, cancellationToken);
    }

    protected override Task ValidateDeleteAsync(PayrollRecord entity, CancellationToken cancellationToken)
    {
        if (entity.Status != PayrollStatus.Draft)
        {
            throw new BusinessRuleException("Only draft payroll records can be deleted.");
        }

        return Task.CompletedTask;
    }

    private async Task ValidateRulesAsync(PayrollDto dto, CancellationToken cancellationToken)
    {
        if (dto.PeriodEnd > clock.Today)
        {
            throw new BusinessRuleException("Payroll cannot be finalized for a future period.");
        }

        if (await UnitOfWork.Repository<Employee>().GetByIdAsync(dto.EmployeeId, cancellationToken) is null)
        {
            throw new BusinessRuleException("Payroll requires an existing employee.");
        }

        IRepository<PayrollRecord> records = UnitOfWork.Repository<PayrollRecord>();
        if (await records.AnyAsync(
            records.Query().Where(record =>
                record.Id != dto.Id
                && record.EmployeeId == dto.EmployeeId
                && record.PeriodStart == dto.PeriodStart
                && record.PeriodEnd == dto.PeriodEnd
                && record.Status != PayrollStatus.Voided),
            cancellationToken))
        {
            throw new ConflictException("A payroll record already exists for the employee and period.");
        }
    }
}
