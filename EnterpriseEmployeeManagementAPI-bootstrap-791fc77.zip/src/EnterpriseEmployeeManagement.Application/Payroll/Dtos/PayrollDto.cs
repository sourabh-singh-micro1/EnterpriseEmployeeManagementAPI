using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Domain.Enums;

namespace EnterpriseEmployeeManagement.Application.Payroll.Dtos;

public sealed class PayrollDto : IResourceDto
{
    public Guid Id { get; set; }

    public Guid EmployeeId { get; set; }

    public DateOnly PeriodStart { get; set; }

    public DateOnly PeriodEnd { get; set; }

    public decimal GrossPay { get; set; }

    public decimal Deductions { get; set; }

    public decimal NetPay { get; set; }

    public string Currency { get; set; } = "USD";

    public PayrollStatus Status { get; set; } = PayrollStatus.Draft;
}
