using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Payroll.Validators;

public sealed class PayrollDtoValidator : AbstractValidator<PayrollDto>
{
    public PayrollDtoValidator()
    {
        RuleFor(x => x.EmployeeId).NotEmpty();
        RuleFor(x => x.PeriodEnd).GreaterThanOrEqualTo(x => x.PeriodStart);
        RuleFor(x => x.GrossPay).GreaterThanOrEqualTo(0);
        RuleFor(x => x.Deductions).GreaterThanOrEqualTo(0).LessThanOrEqualTo(x => x.GrossPay);
        RuleFor(x => x.NetPay).Equal(x => x.GrossPay - x.Deductions);
        RuleFor(x => x.Currency).NotEmpty().Length(3);
    }
}
