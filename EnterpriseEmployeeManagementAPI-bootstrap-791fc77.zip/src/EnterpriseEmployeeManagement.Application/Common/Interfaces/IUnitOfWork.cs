using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Application.Common.Interfaces;

public interface IUnitOfWork
{
    IRepository<TEntity> Repository<TEntity>()
        where TEntity : BaseEntity;

    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
}
