using EnterpriseEmployeeManagement.Application.Common.Models;
using EnterpriseEmployeeManagement.Domain.Entities;

namespace EnterpriseEmployeeManagement.Application.Common.Interfaces;

public interface IClock
{
    DateTimeOffset UtcNow { get; }

    DateOnly Today { get; }
}

public interface IPasswordHasher
{
    string Hash(string password);

    bool Verify(string password, string passwordHash);
}

public interface ITokenService
{
    IssuedTokenSet Issue(UserAccount user, string roleName);
}

public interface ICurrentUserService
{
    Guid? UserId { get; }

    Guid? EmployeeId { get; }

    string? Role { get; }

    bool IsAuthenticated { get; }
}
