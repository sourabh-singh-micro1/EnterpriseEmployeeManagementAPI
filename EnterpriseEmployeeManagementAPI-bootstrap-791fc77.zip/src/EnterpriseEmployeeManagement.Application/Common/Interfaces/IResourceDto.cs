namespace EnterpriseEmployeeManagement.Application.Common.Interfaces;

public interface IResourceDto
{
    Guid Id { get; set; }
}
