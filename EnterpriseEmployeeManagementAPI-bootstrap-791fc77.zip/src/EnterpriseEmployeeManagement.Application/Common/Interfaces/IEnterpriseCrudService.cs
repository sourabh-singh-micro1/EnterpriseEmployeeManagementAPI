using EnterpriseEmployeeManagement.Application.Common.Models;

namespace EnterpriseEmployeeManagement.Application.Common.Interfaces;

public interface IEnterpriseCrudService<TDto>
    where TDto : class, IResourceDto
{
    Task<PagedResult<TDto>> GetPageAsync(PagedQuery query, CancellationToken cancellationToken);

    Task<TDto> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task<TDto> CreateAsync(TDto dto, CancellationToken cancellationToken);

    Task<TDto> UpdateAsync(Guid id, TDto dto, CancellationToken cancellationToken);

    Task DeleteAsync(Guid id, CancellationToken cancellationToken);
}
