using EnterpriseEmployeeManagement.Domain.Common;

namespace EnterpriseEmployeeManagement.Application.Common.Interfaces;

public interface IRepository<TEntity>
    where TEntity : BaseEntity
{
    IQueryable<TEntity> Query(bool asNoTracking = true);

    Task<TEntity?> GetByIdAsync(Guid id, CancellationToken cancellationToken);

    Task AddAsync(TEntity entity, CancellationToken cancellationToken);

    void Update(TEntity entity);

    void Remove(TEntity entity);

    Task<int> CountAsync(IQueryable<TEntity> query, CancellationToken cancellationToken);

    Task<IReadOnlyList<TEntity>> ListAsync(IQueryable<TEntity> query, CancellationToken cancellationToken);

    Task<bool> AnyAsync(IQueryable<TEntity> query, CancellationToken cancellationToken);
}
