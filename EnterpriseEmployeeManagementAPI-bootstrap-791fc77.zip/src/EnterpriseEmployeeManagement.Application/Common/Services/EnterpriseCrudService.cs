using System.ComponentModel;
using System.Globalization;
using System.Linq.Expressions;
using System.Reflection;
using AutoMapper;
using EnterpriseEmployeeManagement.Application.Common.Exceptions;
using EnterpriseEmployeeManagement.Application.Common.Interfaces;
using EnterpriseEmployeeManagement.Application.Common.Models;
using EnterpriseEmployeeManagement.Domain.Common;
using FluentValidation;

namespace EnterpriseEmployeeManagement.Application.Common.Services;

public abstract class EnterpriseCrudService<TEntity, TDto> : IEnterpriseCrudService<TDto>
    where TEntity : BaseEntity
    where TDto : class, IResourceDto
{
    protected EnterpriseCrudService(
        IUnitOfWork unitOfWork,
        IMapper mapper,
        IValidator<TDto> validator)
    {
        UnitOfWork = unitOfWork;
        Mapper = mapper;
        Validator = validator;
    }

    protected IUnitOfWork UnitOfWork { get; }

    protected IMapper Mapper { get; }

    protected IValidator<TDto> Validator { get; }

    public async Task<PagedResult<TDto>> GetPageAsync(PagedQuery query, CancellationToken cancellationToken)
    {
        IRepository<TEntity> repository = UnitOfWork.Repository<TEntity>();
        IQueryable<TEntity> entities = repository.Query();
        entities = ApplySearch(entities, query.Search);
        entities = ApplyFilter(entities, query.FilterBy, query.FilterValue);
        entities = ApplySort(entities, query.SortBy, query.SortDescending);

        int totalCount = await repository.CountAsync(entities, cancellationToken);
        IReadOnlyList<TEntity> page = await repository.ListAsync(
            entities.Skip((query.SafePageNumber - 1) * query.SafePageSize).Take(query.SafePageSize),
            cancellationToken);

        IReadOnlyCollection<TDto> items = page.Select(Mapper.Map<TDto>).ToArray();
        return new PagedResult<TDto>(items, query.SafePageNumber, query.SafePageSize, totalCount);
    }

    public async Task<TDto> GetByIdAsync(Guid id, CancellationToken cancellationToken)
    {
        TEntity entity = await GetRequiredEntityAsync(id, cancellationToken);
        return Mapper.Map<TDto>(entity);
    }

    public virtual async Task<TDto> CreateAsync(TDto dto, CancellationToken cancellationToken)
    {
        dto.Id = Guid.Empty;
        await Validator.ValidateAndThrowAsync(dto, cancellationToken);
        await ValidateCreateAsync(dto, cancellationToken);

        TEntity entity = Mapper.Map<TEntity>(dto);
        entity.Id = Guid.NewGuid();
        AfterMapForCreate(entity, dto);
        await UnitOfWork.Repository<TEntity>().AddAsync(entity, cancellationToken);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
        return Mapper.Map<TDto>(entity);
    }

    public virtual async Task<TDto> UpdateAsync(Guid id, TDto dto, CancellationToken cancellationToken)
    {
        dto.Id = id;
        await Validator.ValidateAndThrowAsync(dto, cancellationToken);
        TEntity entity = await GetRequiredEntityAsync(id, cancellationToken);
        await ValidateUpdateAsync(entity, dto, cancellationToken);
        Mapper.Map(dto, entity);
        AfterMapForUpdate(entity, dto);
        UnitOfWork.Repository<TEntity>().Update(entity);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
        return Mapper.Map<TDto>(entity);
    }

    public virtual async Task DeleteAsync(Guid id, CancellationToken cancellationToken)
    {
        TEntity entity = await GetRequiredEntityAsync(id, cancellationToken);
        await ValidateDeleteAsync(entity, cancellationToken);
        UnitOfWork.Repository<TEntity>().Remove(entity);
        await UnitOfWork.SaveChangesAsync(cancellationToken);
    }

    protected virtual Task ValidateCreateAsync(TDto dto, CancellationToken cancellationToken) => Task.CompletedTask;

    protected virtual Task ValidateUpdateAsync(TEntity entity, TDto dto, CancellationToken cancellationToken) => Task.CompletedTask;

    protected virtual Task ValidateDeleteAsync(TEntity entity, CancellationToken cancellationToken) => Task.CompletedTask;

    protected virtual void AfterMapForCreate(TEntity entity, TDto dto)
    {
    }

    protected virtual void AfterMapForUpdate(TEntity entity, TDto dto)
    {
    }

    protected async Task<TEntity> GetRequiredEntityAsync(Guid id, CancellationToken cancellationToken)
    {
        return await UnitOfWork.Repository<TEntity>().GetByIdAsync(id, cancellationToken)
            ?? throw new NotFoundException(typeof(TEntity).Name, id);
    }

    private static IQueryable<TEntity> ApplySearch(IQueryable<TEntity> query, string? search)
    {
        if (string.IsNullOrWhiteSpace(search))
        {
            return query;
        }

        PropertyInfo[] properties = typeof(TEntity).GetProperties()
            .Where(property => property.PropertyType == typeof(string))
            .ToArray();
        if (properties.Length == 0)
        {
            return query;
        }

        ParameterExpression parameter = Expression.Parameter(typeof(TEntity), "entity");
        ConstantExpression term = Expression.Constant(search.Trim().ToLowerInvariant());
        MethodInfo contains = typeof(string).GetMethod(nameof(string.Contains), [typeof(string)])!;
        MethodInfo toLower = typeof(string).GetMethod(nameof(string.ToLower), Type.EmptyTypes)!;
        Expression? body = null;

        foreach (PropertyInfo property in properties)
        {
            MemberExpression member = Expression.Property(parameter, property);
            BinaryExpression notNull = Expression.NotEqual(member, Expression.Constant(null, typeof(string)));
            MethodCallExpression value = Expression.Call(Expression.Call(member, toLower), contains, term);
            Expression predicate = Expression.AndAlso(notNull, value);
            body = body is null ? predicate : Expression.OrElse(body, predicate);
        }

        return query.Where(Expression.Lambda<Func<TEntity, bool>>(body!, parameter));
    }

    private static IQueryable<TEntity> ApplyFilter(IQueryable<TEntity> query, string? filterBy, string? filterValue)
    {
        if (string.IsNullOrWhiteSpace(filterBy) || filterValue is null)
        {
            return query;
        }

        PropertyInfo? property = FindProperty(filterBy);
        if (property is null)
        {
            throw new BusinessRuleException($"Filtering by '{filterBy}' is not supported.");
        }

        Type targetType = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
        object? value = ConvertValue(filterValue, targetType);
        ParameterExpression parameter = Expression.Parameter(typeof(TEntity), "entity");
        MemberExpression member = Expression.Property(parameter, property);
        Expression constant = Expression.Constant(value, targetType);
        Expression comparableMember = targetType == property.PropertyType ? member : Expression.Convert(member, targetType);
        BinaryExpression equality = Expression.Equal(comparableMember, constant);
        return query.Where(Expression.Lambda<Func<TEntity, bool>>(equality, parameter));
    }

    private static IQueryable<TEntity> ApplySort(IQueryable<TEntity> query, string? sortBy, bool descending)
    {
        PropertyInfo property = FindProperty(sortBy ?? nameof(BaseEntity.CreatedAtUtc))
            ?? typeof(TEntity).GetProperty(nameof(BaseEntity.CreatedAtUtc))!;
        ParameterExpression parameter = Expression.Parameter(typeof(TEntity), "entity");
        LambdaExpression keySelector = Expression.Lambda(Expression.Property(parameter, property), parameter);
        string methodName = descending ? nameof(Queryable.OrderByDescending) : nameof(Queryable.OrderBy);
        MethodCallExpression call = Expression.Call(
            typeof(Queryable),
            methodName,
            [typeof(TEntity), property.PropertyType],
            query.Expression,
            Expression.Quote(keySelector));
        return query.Provider.CreateQuery<TEntity>(call);
    }

    private static PropertyInfo? FindProperty(string name)
    {
        return typeof(TEntity).GetProperties()
            .FirstOrDefault(property => property.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
    }

    private static object? ConvertValue(string value, Type targetType)
    {
        if (targetType == typeof(Guid))
        {
            return Guid.Parse(value);
        }

        if (targetType == typeof(DateOnly))
        {
            return DateOnly.Parse(value, CultureInfo.InvariantCulture);
        }

        if (targetType.IsEnum)
        {
            return Enum.Parse(targetType, value, ignoreCase: true);
        }

        TypeConverter converter = TypeDescriptor.GetConverter(targetType);
        return converter.ConvertFromInvariantString(value);
    }
}
