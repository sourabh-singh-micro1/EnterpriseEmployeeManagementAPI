namespace EnterpriseEmployeeManagement.Application.Common.Models;

public sealed record IssuedTokenSet(
    string AccessToken,
    string RefreshToken,
    string RefreshTokenHash,
    DateTimeOffset ExpiresAtUtc);
