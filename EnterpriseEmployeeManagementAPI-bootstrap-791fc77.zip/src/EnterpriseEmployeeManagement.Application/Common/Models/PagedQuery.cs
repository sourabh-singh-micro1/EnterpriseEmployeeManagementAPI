namespace EnterpriseEmployeeManagement.Application.Common.Models;

public sealed record PagedQuery(
    int PageNumber = 1,
    int PageSize = 20,
    string? Search = null,
    string? SortBy = null,
    bool SortDescending = false,
    string? FilterBy = null,
    string? FilterValue = null)
{
    public int SafePageNumber => Math.Max(PageNumber, 1);

    public int SafePageSize => Math.Clamp(PageSize, 1, 100);
}
