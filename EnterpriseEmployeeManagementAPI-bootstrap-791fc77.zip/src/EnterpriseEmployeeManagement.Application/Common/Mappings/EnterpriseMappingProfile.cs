using AutoMapper;
using EnterpriseEmployeeManagement.Application.Attendance.Dtos;
using EnterpriseEmployeeManagement.Application.Departments.Dtos;
using EnterpriseEmployeeManagement.Application.Employees.Dtos;
using EnterpriseEmployeeManagement.Application.LeaveManagement.Dtos;
using EnterpriseEmployeeManagement.Application.Payroll.Dtos;
using EnterpriseEmployeeManagement.Application.PerformanceReviews.Dtos;
using EnterpriseEmployeeManagement.Application.Projects.Dtos;
using EnterpriseEmployeeManagement.Application.Roles.Dtos;
using EnterpriseEmployeeManagement.Application.UserManagement.Dtos;
using EnterpriseEmployeeManagement.Domain.Entities;

namespace EnterpriseEmployeeManagement.Application.Common.Mappings;

public sealed class EnterpriseMappingProfile : Profile
{
    public EnterpriseMappingProfile()
    {
        CreateMap<Employee, EmployeeDto>().ReverseMap();
        CreateMap<Department, DepartmentDto>().ReverseMap();
        CreateMap<Project, ProjectDto>().ReverseMap();
        CreateMap<AttendanceRecord, AttendanceDto>().ReverseMap();
        CreateMap<LeaveRequest, LeaveRequestDto>().ReverseMap();
        CreateMap<Role, RoleDto>().ReverseMap();
        CreateMap<PayrollRecord, PayrollDto>().ReverseMap();
        CreateMap<PerformanceReview, PerformanceReviewDto>().ReverseMap();
        CreateMap<UserAccount, UserDto>()
            .ForMember(destination => destination.Password, option => option.Ignore());
        CreateMap<UserDto, UserAccount>()
            .ForMember(destination => destination.PasswordHash, option => option.Ignore())
            .ForMember(destination => destination.FailedLoginAttempts, option => option.Ignore());
    }
}
