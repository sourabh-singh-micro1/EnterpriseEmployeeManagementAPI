param(
    [Parameter(Mandatory = $false)]
    [string] $ResultsDirectory = "TestResults",
    [Parameter(Mandatory = $false)]
    [double] $Minimum = 0.80
)

$reports = Get-ChildItem -Path $ResultsDirectory -Recurse -Filter "coverage.cobertura.xml"
if ($reports.Count -eq 0) {
    throw "No Cobertura coverage reports were found under '$ResultsDirectory'."
}

$covered = 0
$valid = 0
foreach ($report in $reports) {
    [xml] $document = Get-Content -Raw -LiteralPath $report.FullName
    $covered += [int] $document.coverage.'lines-covered'
    $valid += [int] $document.coverage.'lines-valid'
}

if ($valid -eq 0) {
    throw "Coverage reports contain no instrumented lines."
}

$rate = $covered / $valid
Write-Host ("Combined line coverage: {0:P2} ({1}/{2})" -f $rate, $covered, $valid)
if ($rate -lt $Minimum) {
    throw ("Line coverage {0:P2} is below the required {1:P0}." -f $rate, $Minimum)
}
