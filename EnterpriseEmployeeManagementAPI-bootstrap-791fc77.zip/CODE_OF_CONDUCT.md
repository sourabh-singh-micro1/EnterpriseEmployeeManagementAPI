# Code of Conduct

We are committed to a respectful, harassment-free project. Be constructive, assume good intent, protect private employee information, and focus reviews on the code and its impact. Unacceptable conduct includes harassment, discrimination, threats, deliberate disclosure of private information, and sustained disruption.

Report concerns privately to the repository owner. Maintainers may edit or remove content and restrict participation when needed to protect the community.
