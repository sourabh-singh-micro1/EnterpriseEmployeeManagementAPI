# EnterpriseEmployeeManagementAPI

A production-oriented ASP.NET Core 10 employee-management reference system designed for enterprise API development and realistic AI-assisted pull-request review exercises.

## Architecture

- **API** — REST endpoints, JWT authorization, Swagger UI, middleware, health endpoints.
- **Application** — DTOs, validation, mapping, use-case services, repository abstractions.
- **Domain** — entities, enums, domain invariants, and shared primitives.
- **Infrastructure** — EF Core SQL Server, repositories, migrations, identity services, background jobs.
- **Tests** — xUnit/Moq unit tests and WebApplicationFactory integration tests.

## Modules

Authentication, Employees, Departments, Projects, Attendance, Leave Management, Roles, User Management, Payroll, and Performance Reviews. Resource endpoints expose CRUD, pagination, free-text search, field filtering, and sorting. Business rules include department budget enforcement, leave-overlap detection, payroll finalization, attendance limits, system-role protection, lockout-aware authentication, and review-cycle validation.

## Quick start

Prerequisites: .NET 10 SDK and SQL Server (or the supplied Docker Compose stack).

```bash
dotnet restore
dotnet build --no-restore
docker compose up -d sqlserver
dotnet run --project src/EnterpriseEmployeeManagement.Api
```

Open `https://localhost:7001/swagger`. Development seed credentials are documented in `docs/development-seed.md`; replace every secret outside local development.

## Quality gates

```bash
dotnet format --verify-no-changes
dotnet test --collect:"XPlat Code Coverage" --settings tests/coverage.runsettings
dotnet list package --vulnerable --include-transitive
```

CI enforces restore, build, tests, formatting, analyzers, dependency audit, artifacts, CodeQL, and an 80% coverage threshold for the business-logic coverage scope. See `docs/branch-protection.md` for required repository settings.

## Review-assistant scenarios

A small set of safe, non-breaking maintainability issues is intentionally retained in `src/EnterpriseEmployeeManagement.Application/ReviewScenarios`. They exercise duplication, inefficient enumeration, nullable safety, low-observability exception handling, and string-allocation review rules. See `docs/review-scenarios.md` for the maintainer key.

## Security

Never commit production secrets. Configure JWT and SQL Server credentials through environment variables, user-secrets, or a managed secret store. Report vulnerabilities according to [SECURITY.md](SECURITY.md).

## License

Provided as a portfolio and testing reference. Add the license selected by the repository owner before redistribution.
