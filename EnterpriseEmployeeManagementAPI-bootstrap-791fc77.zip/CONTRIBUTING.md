# Contributing

1. Create an issue or agree on scope.
2. Branch from `main` using `feature/<issue>-<description>` or `fix/<issue>-<description>`.
3. Add tests for behavior changes and keep the configured coverage scope at or above 80%.
4. Run restore, format verification, build, tests, and dependency audit locally.
5. Open a focused Pull Request using the template. Two approvals and all required checks are expected.
6. Resolve every review conversation before merge.

Use conventional commit subjects where practical. Do not commit credentials, personal employee data, generated binaries, or local database files.
