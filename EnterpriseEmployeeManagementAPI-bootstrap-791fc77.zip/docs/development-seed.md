# Development seed data

Local development creates the roles Administrator, Manager, HR, and Employee and a sample department. When `SeedData:Enabled` is true, the administrator is:

- Username: `admin`
- Password: `ChangeMe!12345`

This credential is rejected by configuration validation outside Development. Override it with `SeedData__AdministratorPassword` and use a secret store.
