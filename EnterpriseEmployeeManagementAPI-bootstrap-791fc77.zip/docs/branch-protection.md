# Recommended branch protection

Configure a ruleset for `main` with:

- Require a Pull Request and at least **two approvals**.
- Dismiss stale approvals after new commits and require review from CODEOWNERS.
- Require conversation resolution before merge.
- Require signed commits where organizational policy supports them.
- Require branches to be up to date.
- Require status checks: `quality / format-and-build`, `tests / unit-and-integration`, `security / dependency-audit`, `CodeQL / Analyze (csharp)`, and `coverage / enforce-80-percent`.
- Block force pushes and deletion.
- Apply rules to administrators.
- Require deployments for production when a deployment environment is added.

GitHub cannot express a coverage percentage directly as a branch rule; require the named coverage job, which fails below 80%.
