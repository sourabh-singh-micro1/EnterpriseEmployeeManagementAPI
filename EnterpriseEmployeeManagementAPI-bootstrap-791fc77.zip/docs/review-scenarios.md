# Intentional review scenarios

These safe defects exist only to exercise review automation and are excluded from security-critical paths:

1. Duplicate export-formatting methods.
2. Repeated enumeration of an in-memory sequence.
3. A nullable dereference guarded by a compiler-warning suppression.
4. A swallowed exception in a best-effort reconciliation helper.
5. Repeated string concatenation in a small legacy report loop.
6. An auto-generated formatting fixture.

They must never involve secrets, authorization bypasses, injection, unsafe deserialization, or production data loss. Remove or fix them before using this repository as a production baseline.
