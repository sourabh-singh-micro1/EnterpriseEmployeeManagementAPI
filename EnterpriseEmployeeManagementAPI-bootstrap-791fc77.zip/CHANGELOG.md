# Changelog

All notable changes follow Keep a Changelog principles and semantic versioning.

## [Unreleased]

### Added

- Initial Clean Architecture employee-management API.
