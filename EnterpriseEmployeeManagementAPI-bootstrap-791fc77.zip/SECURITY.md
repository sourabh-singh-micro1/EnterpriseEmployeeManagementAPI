# Security Policy

## Supported versions

Security fixes are applied to the latest `main` branch and the latest tagged release.

## Reporting

Do not open a public issue for a suspected vulnerability. Use GitHub private vulnerability reporting when enabled, or contact the repository owner privately. Include reproduction steps, impact, affected endpoints, and a suggested mitigation if known.

Never include real employee records, credentials, JWT signing keys, or connection strings in a report. Maintainers will acknowledge reports within five business days and coordinate remediation and disclosure.
